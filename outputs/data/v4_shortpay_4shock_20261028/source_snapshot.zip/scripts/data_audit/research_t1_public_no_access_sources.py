"""Audit public T1 options that need no affiliation, sponsor, or partner export.

The script deliberately separates three questions:

* whether a source is publicly reachable and reusable;
* whether multiple public buyers can be re-indexed into seller-to-buyers panels;
* whether the resulting rows contain the event semantics required by T1.

Raw network snapshots are inspection-only and remain below ``data/T1/raw``.
Committed output contains only aggregate results, URLs, hashes, and limitations;
it does not repeat public business names, addresses, or tax identifiers.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import statistics
import urllib.error
import urllib.parse
import urllib.request
import zipfile


ROOT = Path(__file__).resolve().parents[2]
RESEARCH_DATE = "2026-10-22"
MAX_BYTES = 20_000_000
SLOVAK_SAMPLE_SIZE = 24
SLOVAK_CATALOG = "https://data.mpsvr.gov.sk/api/3/action/"
SLOVAK_METHOD = (
    "https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20056665/Fakt%2Bry")

KAGGLE_SEARCHES = (
    "invoice payment",
    "accounts receivable",
    "payment delay",
    "payment date prediction",
    "B2B invoice",
    "late payment invoice",
)

KAGGLE_CANDIDATES = {
    "ingeborgbevers/customer-payment-behaviour": "synthetic_explicit",
    "mostafahisham1987/account-receivable-and-payable-analytics-dashboard":
        "small_dashboard_demo",
    "willianoliveiragibin/finance-company-receivables": "macro_time_series_not_invoices",
    "pradumn203/payment-date-prediction-for-invoices-dataset": "highradius_50000_family",
    "hhenry/finance-factoring-ibm-late-payment-histories": "ibm_sample_unknown_realism",
    "xaysomvangthammavong/lao-fuel-distributor-annual-sales-report-2025":
        "real_sales_no_payment_event",
    "dataslconsulting/french-local-authorities-payment-delays":
        "authority_level_aggregate_not_invoice_rows",
    "kiruthikas005/msme-invoices-and-transactions": "simulated_explicit",
    "tharishreddy22/global-b2b-invoice-and-payments-dataset": "synthetic_explicit",
}

KAGGLE_DOWNLOADS = {
    "willianoliveiragibin/finance-company-receivables",
    "pradumn203/payment-date-prediction-for-invoices-dataset",
    "hhenry/finance-factoring-ibm-late-payment-histories",
    "xaysomvangthammavong/lao-fuel-distributor-annual-sales-report-2025",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def safe_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def request_bytes(url: str, data: bytes | None = None) -> tuple[bytes, int]:
    headers = {"User-Agent": "FinanceProject-T1-PublicResearch/1.0"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=data, headers=headers)
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = response.read(MAX_BYTES + 1)
        if len(payload) > MAX_BYTES:
            raise ValueError(f"Response exceeded {MAX_BYTES} bytes: {url}")
        return payload, response.status


def snapshot_file(folder: Path, name: str, url: str, responses: list,
                  data: bytes | None = None) -> bytes:
    payload, status = request_bytes(url, data=data)
    target = folder / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(payload)
    responses.append({
        "file": name,
        "url": url,
        "method": "POST" if data is not None else "GET",
        "status": status,
        "bytes": len(payload),
        "sha256": sha256(payload),
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
    })
    return payload


def validate_snapshot(folder: Path) -> dict:
    manifest = read_json(folder / "source_manifest.json")
    for item in manifest["responses"]:
        if not (isinstance(item.get("status"), int) and 200 <= item["status"] < 300):
            continue
        target = folder / item["file"]
        payload = target.read_bytes()
        if len(payload) != item["bytes"] or sha256(payload) != item["sha256"]:
            raise ValueError(f"Cached bytes differ for {item['file']}")
    return manifest


def build_snapshot(folder: Path, offline: bool) -> dict:
    manifest_path = folder / "source_manifest.json"
    if manifest_path.exists():
        return validate_snapshot(folder)
    if offline:
        raise ValueError("Offline mode requires an existing complete snapshot")
    if folder.exists() and any(folder.iterdir()):
        raise ValueError("Snapshot directory is non-empty but has no manifest")
    folder.mkdir(parents=True, exist_ok=True)
    responses = []

    snapshot_file(folder, "slovakia/methodology.html", SLOVAK_METHOD, responses)
    catalog_body = json.dumps({"q": "*:*", "rows": 100}).encode()
    catalog_payload = snapshot_file(
        folder, "slovakia/catalog.json", SLOVAK_CATALOG + "package_search",
        responses, data=catalog_body)
    catalog = json.loads(catalog_payload)["result"]
    invoice_slugs = sorted(
        item["name"].replace("objednavky_", "faktury_", 1)
        for item in catalog["results"] if item["name"].startswith("objednavky_"))
    selected = invoice_slugs[:SLOVAK_SAMPLE_SIZE]
    slovak_packages = []
    for slug in selected:
        body = json.dumps({"id": slug}).encode()
        try:
            payload = snapshot_file(
                folder, f"slovakia/packages/{slug}.json",
                SLOVAK_CATALOG + "package_show", responses, data=body)
        except urllib.error.HTTPError as exc:
            responses.append({
                "file": f"slovakia/packages/{slug}.json", "url": exc.url,
                "method": "POST", "status": exc.code,
                "checked_at_utc": datetime.now(timezone.utc).isoformat(),
            })
            continue
        package = json.loads(payload)["result"]
        json_resources = [
            item for item in package.get("resources", [])
            if str(item.get("format", "")).upper() == "JSON"]
        if not json_resources:
            continue
        resource = json_resources[0]
        raw_name = f"slovakia/invoices/{slug}.json"
        snapshot_file(folder, raw_name, resource["url"], responses)
        slovak_packages.append({
            "slug": slug,
            "metadata_file": f"slovakia/packages/{slug}.json",
            "data_file": raw_name,
        })

    for query in KAGGLE_SEARCHES:
        url = "https://www.kaggle.com/api/v1/datasets/list?" + urllib.parse.urlencode({
            "search": query, "page": 1, "sortBy": "updated"})
        snapshot_file(folder, f"kaggle/search/{safe_name(query)}.json", url, responses)
    for ref in KAGGLE_CANDIDATES:
        stem = safe_name(ref)
        snapshot_file(
            folder, f"kaggle/candidates/{stem}.json",
            "https://www.kaggle.com/api/v1/datasets/view/" + ref, responses)
        if ref in KAGGLE_DOWNLOADS:
            snapshot_file(
                folder, f"kaggle/downloads/{stem}.zip",
                "https://www.kaggle.com/api/v1/datasets/download/" + ref, responses)

    manifest = {
        "research_date": RESEARCH_DATE,
        "use_policy": "inspection_only_not_training_data",
        "slovak_selection": {
            "catalog_packages": catalog["count"],
            "derived_invoice_slugs": len(invoice_slugs),
            "selection_rule": f"lexicographically first {SLOVAK_SAMPLE_SIZE}",
            "selected": selected,
            "downloaded": slovak_packages,
        },
        "responses": responses,
    }
    write_json(manifest_path, manifest)
    return manifest


def parse_iso(value: str | None) -> date | None:
    try:
        return date.fromisoformat(str(value)[:10])
    except (TypeError, ValueError):
        return None


def positive_decimal(value) -> bool:
    try:
        return Decimal(str(value)) > 0
    except (InvalidOperation, TypeError):
        return False


def panel_summary(pair_counts: Counter) -> dict:
    by_seller = defaultdict(list)
    for (seller, buyer), count in pair_counts.items():
        by_seller[seller].append(count)
    profiles = []
    for counts in by_seller.values():
        profiles.append({
            "rows": sum(counts),
            "buyers": len(counts),
            "buyers_with_at_least_2_rows": sum(value >= 2 for value in counts),
            "buyers_with_at_least_5_rows": sum(value >= 5 for value in counts),
            "minimum_rows_per_buyer": min(counts),
            "median_rows_per_buyer": statistics.median(counts),
            "maximum_rows_per_buyer": max(counts),
        })
    profiles.sort(key=lambda item: (
        item["buyers_with_at_least_5_rows"], item["buyers"], item["rows"]), reverse=True)
    return {
        "eligible_rows": sum(pair_counts.values()),
        "distinct_sellers": len(profiles),
        "distinct_buyers": len({buyer for _, buyer in pair_counts}),
        "sellers_with_at_least_2_buyers": sum(item["buyers"] >= 2 for item in profiles),
        "sellers_with_at_least_5_buyers": sum(item["buyers"] >= 5 for item in profiles),
        "sellers_with_at_least_10_buyers": sum(item["buyers"] >= 10 for item in profiles),
        "sellers_with_at_least_5_repeat_buyers": sum(
            item["buyers_with_at_least_2_rows"] >= 5 for item in profiles),
        "sellers_with_at_least_5_buyers_having_5_rows": sum(
            item["buyers_with_at_least_5_rows"] >= 5 for item in profiles),
        "top_anonymous_panels": profiles[:15],
    }


def audit_czech_health(path: Path) -> dict:
    configs = {
        "issue_due_paid_with_reference_and_ordinary_type": Counter(),
        "received_due_paid": Counter(),
    }
    total = 0
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            total += 1
            seller = row.get("seller_id", "").strip()
            buyer = row.get("buyer_id", "").strip()
            if not seller or not buyer:
                continue
            if (row.get("gate_with_invoice_reference") == "True"
                    and row.get("ordinary_named_document_type") == "True"):
                configs["issue_due_paid_with_reference_and_ordinary_type"][(seller, buyer)] += 1
            if row.get("gate_received_due_paid") == "True":
                configs["received_due_paid"][(seller, buyer)] += 1
    return {
        "source_rows": total,
        "cohorts": {name: panel_summary(counts) for name, counts in configs.items()},
        "orientation_result": (
            "The source is many public buyers to many suppliers at publication level. Re-indexing "
            "by supplier creates genuine seller-to-repeat-buyers panels; it is not equivalent to "
            "renaming suppliers as customers inside a single-buyer ledger."),
        "limits": [
            "Paid/observed events only; the publication is not a complete open receivables portfolio.",
            "Receipt-to-payment has broader buyer coverage than issue-to-payment.",
            "Duplicates, document types, partial payments and publication lag still require the existing audit gates.",
        ],
    }


def audit_act(path: Path) -> dict:
    exact = set()
    pair_counts = Counter()
    raw_rows = 0
    with gzip.open(path, "rt", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        for row in reader:
            raw_rows += 1
            values = tuple(row.get(field, "") for field in fields)
            if values in exact:
                continue
            exact.add(values)
            seller = row.get("supplier_abn", "").strip()
            if not seller:
                seller = "NAME:" + row.get("supplier_name", "").strip().upper()
            buyer = row.get("reporting_entity", "").strip()
            received = parse_iso(row.get("date_invoice_received"))
            paid = parse_iso(row.get("payment_date"))
            if (seller != "NAME:" and buyer and received and paid and paid >= received
                    and positive_decimal(row.get("payment_amount"))):
                pair_counts[(seller, buyer)] += 1
    result = panel_summary(pair_counts)
    result.update({
        "source_rows": raw_rows,
        "exact_deduplicated_rows": len(exact),
        "target": "payment_date - date_invoice_received",
        "limits": [
            "No invoice identifier or contractual due date.",
            "Only paid invoices at or above the statutory publication threshold.",
            "Use seller panels only after exact-row deduplication and time-based splitting.",
        ],
    })
    return result


def duration_summary(values: list[int]) -> dict:
    values = sorted(values)
    if not values:
        return {"observations": 0}
    return {
        "observations": len(values),
        "minimum": values[0],
        "median": statistics.median(values),
        "p95": values[int(0.95 * (len(values) - 1))],
        "maximum": values[-1],
    }


def audit_slovakia(folder: Path, manifest: dict) -> dict:
    pair_counts = Counter()
    invoice_keys = Counter()
    missing = Counter()
    durations = []
    total = 0
    states = Counter()
    licenses = Counter()
    packages = manifest["slovak_selection"]["downloaded"]
    for item in packages:
        metadata = read_json(folder / item["metadata_file"])["result"]
        states[metadata.get("state")] += 1
        licenses[metadata.get("license_title")] += 1
        rows = read_json(folder / item["data_file"])
        for row in rows:
            total += 1
            seller = str(row.get("DodavatelICO") or "").strip()
            buyer = str(row.get("ObjednavatelICO") or "").strip()
            invoice = str(row.get("FakturaID") or "").strip()
            received = parse_iso(row.get("FakturaDatumDorucenia"))
            paid = parse_iso(row.get("FakturaDatumUhrady"))
            amount = row.get("FakturaPlnenieHodnotaEur")
            missing["seller"] += not bool(seller)
            missing["buyer"] += not bool(buyer)
            missing["invoice"] += not bool(invoice)
            missing["received"] += received is None
            missing["paid"] += paid is None
            missing["amount"] += amount in (None, "")
            if invoice:
                invoice_keys[(buyer, invoice)] += 1
            canceled = str(row.get("PriznakStorna", "")).lower() == "true"
            if (seller and buyer and received and paid and paid >= received
                    and positive_decimal(amount) and not canceled):
                pair_counts[(seller, buyer)] += 1
                durations.append((paid - received).days)
    result = panel_summary(pair_counts)
    result.update({
        "sample_rule": manifest["slovak_selection"]["selection_rule"],
        "derived_invoice_slugs_in_catalog": manifest["slovak_selection"]["derived_invoice_slugs"],
        "packages_downloaded": len(packages),
        "package_states": dict(states),
        "licenses": dict(licenses),
        "source_rows": total,
        "distinct_invoice_keys": len(invoice_keys),
        "invoice_keys_repeated": sum(value > 1 for value in invoice_keys.values()),
        "missing": dict(missing),
        "received_to_payment_days": duration_summary(durations),
        "target": "FakturaDatumUhrady - FakturaDatumDorucenia",
        "limits": [
            "The sampled CKAN packages were marked deleted although their public resource URLs still resolved.",
            "The CES publication contains paid incoming supplier invoices only.",
            "CES records first-payment date and full invoice amount for instalment-paid invoices according to the official methodology.",
            "The inspected CES v2 rows do not provide contractual due date or open items.",
        ],
    })
    return result


def csv_member_profile(zip_path: Path) -> dict:
    with zipfile.ZipFile(zip_path) as archive:
        members = [item for item in archive.infolist() if item.filename.lower().endswith(".csv")]
        if len(members) != 1:
            return {"csv_members": [item.filename for item in members]}
        member = members[0]
        with archive.open(member) as binary:
            reader = csv.DictReader(io.TextIOWrapper(binary, encoding="utf-8-sig", newline=""))
            rows = list(reader)
    return {
        "archive_sha256": sha256(zip_path.read_bytes()),
        "file": member.filename,
        "rows": len(rows),
        "fields": reader.fieldnames,
        "records": rows,
    }


def audit_kaggle(folder: Path) -> dict:
    search_refs = set()
    for query in KAGGLE_SEARCHES:
        for item in read_json(folder / f"kaggle/search/{safe_name(query)}.json"):
            if item.get("ref"):
                search_refs.add(item["ref"])
    candidates = {}
    profiles = {}
    for ref, classification in KAGGLE_CANDIDATES.items():
        stem = safe_name(ref)
        metadata = read_json(folder / f"kaggle/candidates/{stem}.json")
        candidates[ref] = {
            "url": metadata.get("urlNullable") or metadata.get("url"),
            "title": metadata.get("title"),
            "license_name": metadata.get("licenseName"),
            "total_bytes": metadata.get("totalBytes"),
            "classification": classification,
            "publisher_description_excerpt": (metadata.get("description") or "")[:500],
        }
        zip_path = folder / f"kaggle/downloads/{stem}.zip"
        if zip_path.exists():
            profile = csv_member_profile(zip_path)
            rows = profile.pop("records", [])
            fields = profile.get("fields") or []
            if ref == "hhenry/finance-factoring-ibm-late-payment-histories":
                counts = Counter(row.get("customerID", "") for row in rows)
                profile.update({
                    "distinct_customers": len(counts),
                    "customers_with_more_than_one_invoice": sum(value > 1 for value in counts.values()),
                    "missing_settled_date": sum(not row.get("SettledDate") for row in rows),
                })
            elif ref == "pradumn203/payment-date-prediction-for-invoices-dataset":
                profile.update({
                    "missing_clear_date": sum(not row.get("clear_date") for row in rows),
                    "distinct_customer_ids": len({row.get("cust_number") for row in rows}),
                })
            elif ref == "xaysomvangthammavong/lao-fuel-distributor-annual-sales-report-2025":
                profile.update({
                    "distinct_invoice_numbers": len({row.get("invoice_no") for row in rows}),
                    "distinct_customers": len({row.get("customer_code") for row in rows}),
                    "has_payment_or_settlement_date": any(
                        "payment" in field.lower() or "settle" in field.lower() for field in fields),
                })
            profiles[ref] = profile
    return {
        "search_terms": list(KAGGLE_SEARCHES),
        "unique_refs_in_first_pages": len(search_refs),
        "candidates": candidates,
        "downloaded_profiles": profiles,
        "decision": (
            "No newly searched Kaggle candidate combines verified real provenance, invoice issue/due, "
            "payment events, open items, and a stable seller-to-repeat-buyers panel. Keep IBM/HighRadius "
            "families as auxiliary or toy lanes, not the principal claim of real-data validation."),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=(
        ROOT / "data/T1/raw/public_no_access_research/2026-10-22"))
    parser.add_argument("--output", type=Path, default=(
        ROOT / "research/references/data-checks/t1/t1_public_no_access_research.json"))
    parser.add_argument("--czech-health", type=Path, default=(
        ROOT / "data/T1/interim/czech/2026-10-18/health_invoice_audit.csv"))
    parser.add_argument("--act", type=Path, default=(
        ROOT / "data/T1/raw/adjacent_source_research/2026-10-21-v4/act/data.csv.gz"))
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()

    manifest = build_snapshot(args.input, args.offline)
    output = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "research_date": RESEARCH_DATE,
        "scope": (
            "Public sources usable by a five-student competition team without affiliation, funding, "
            "TRE approval, or a business data export."),
        "script_sha256": sha256(Path(__file__).read_bytes()),
        "source_manifest_sha256": sha256((args.input / "source_manifest.json").read_bytes()),
        "czech_health_reindexed_by_seller": audit_czech_health(args.czech_health),
        "act_reindexed_by_supplier": audit_act(args.act),
        "slovakia_ces_sample": audit_slovakia(args.input, manifest),
        "kaggle_expanded_search": audit_kaggle(args.input),
        "recommended_competition_design": {
            "primary_real_lane": (
                "Czech health issue-level seller panels for issue-to-payment; add the broader "
                "receipt-to-payment cohort as a separate target."),
            "external_real_lane": (
                "ACT and sampled Slovak CES seller panels for receipt-to-payment robustness only."),
            "auxiliary_lane": (
                "IBM 2,466-row sample and public HighRadius-family files for pipeline comparison, "
                "with sample/unverified provenance labels."),
            "claim_boundary": (
                "Observed-paid B2G invoice timing across repeat public buyers; not a complete open-AR "
                "portfolio, not SME-Vietnam validation, and not survival validation on open invoices."),
        },
    }
    write_json(args.output, output)
    print(json.dumps({
        "output": str(args.output),
        "script_sha256": output["script_sha256"],
        "czech_issue_rows": output["czech_health_reindexed_by_seller"]["cohorts"]
            ["issue_due_paid_with_reference_and_ordinary_type"]["eligible_rows"],
        "slovak_rows": output["slovakia_ces_sample"]["source_rows"],
    }, indent=2))


if __name__ == "__main__":
    main()
