"""Screen public B2G registries against one issue-to-payment contract.

This is an access, schema, timeline, and provenance screen. It does not promote
a source to training data without a row-level audit. Unknown fields remain null;
portal labels and payment-status fields are never treated as actual payment dates.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.request


ROOT = Path(__file__).resolve().parents[2]
CHECKED_ON = "2026-10-22"
SAMPLE_LIMIT = 1_000_000
POOL_WINDOW = {"start": "2021-01-01", "end": "2025-12-31"}
REQUIRED_FIELDS = (
    "invoice_id", "seller_id", "buyer_id", "issue_date", "due_date",
    "payment_date", "amount", "currency",
)


def schema(**values) -> dict:
    unknown = set(values) - set(REQUIRED_FIELDS)
    if unknown:
        raise ValueError(f"Unknown schema fields: {sorted(unknown)}")
    return {field: values.get(field) for field in REQUIRED_FIELDS}


SOURCES = [
    {
        "country": "CZ", "name": "Czech Health invoice registry",
        "url": "https://faktury.mzcr.cz/site/otevrena-data",
        "coverage": {"start": "2019-01-01", "end": "2026-09-30", "basis": "audited local snapshot"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "downloaded_and_audited", "actual_payment_semantics": "published paid date",
        "population": "observed-paid invoices; 7 public buyers in the strict issue/due/paid cohort",
        "license": "public official API; redistribution terms still require final confirmation",
        "decision": "current_build_with_reuse_caveat",
        "reason": "Only source already audited at row level against the complete target schema.",
    },
    {
        "country": "CZ", "name": "NKOD MZP-family paid-invoice CSVs",
        "url": "https://data.gov.cz/datov%C3%A9-sady?kl%C3%AD%C4%8Dov%C3%A1-slova=faktury",
        "coverage": {"start": "2015-01-01", "end": "2017-12-31", "basis": "usable rows with materially populated payment_date in audited snapshot"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "downloaded_and_audited", "actual_payment_semantics": "datum_uhrady",
        "population": "seven agencies; payment_date is materially populated mainly in 2015-2017",
        "license": "CC0 verified through NKOD metadata",
        "decision": "reject_common_timeline",
        "reason": "Complete declared schema, but zero accepted modern rows in the 2019-2026 build window.",
    },
    {
        "country": "US", "name": "Los Angeles Checkbook L.A.",
        "url": "https://controllerdata.lacity.org/w/pggv-e4fn/default",
        "coverage": {"start": "2012-07-01", "end": "2026-10-01", "basis": "official portal metadata"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "official_portal_visible_api_blocked_in_probe",
        "actual_payment_semantics": "transaction date on a PAID row; raw audit pending",
        "population": "city payments across departments; line-level records require invoice collapse audit",
        "license": "CC BY 4.0 reported by official Socrata attribution",
        "decision": "priority_full_schema_candidate",
        "reason": "Only new lead with the full field set and complete 2021-2025 overlap; download and grain audit are next.",
    },
    {
        "country": "CO", "name": "SECOP II payment plan / invoices",
        "url": "https://www.datos.gov.co/en/Estad-sticas-Nacionales/SECOP-II-Plan-de-pagos/uymx-8p3j",
        "coverage": {"start": None, "end": "2026-07-08", "basis": "official metadata; historical minimum not verified"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=False,
                         amount=True, currency=True),
        "row_access": "official_socrata_api_blocked_in_probe",
        "actual_payment_semantics": "status exists, but no actual payment-date column is documented",
        "population": "national multi-buyer contracts and supplier payment requests",
        "license": "not captured from inspected metadata",
        "decision": "reject_missing_actual_payment_date",
        "reason": "Rich invoice schema cannot label issue-to-payment without the date payment actually occurred.",
    },
    {
        "country": "BR", "name": "Compras.gov.br Contratos invoices",
        "url": "https://repositorio.dados.gov.br/seges/comprasnet_contratos/mensal/",
        "coverage": {"start": "2021-01-01", "end": "2026-07-10", "basis": "official annual/monthly archive index"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=False,
                         amount=True, currency=None),
        "row_access": "public_csv_archive", "actual_payment_semantics": "invoice liquidation/status is not actual cash payment",
        "population": "federal contract invoices; a separate payment API exists but a stable public join is unverified",
        "license": "official open-data repository; exact dataset reuse notice needs capture",
        "decision": "reject_until_payment_join_audited",
        "reason": "Timeline aligns, but the public invoice export alone lacks the required actual payment date.",
    },
    {
        "country": "GB", "name": "Barnet financial invoice late payments",
        "url": "https://www.data.gov.uk/dataset/721ea736-1fee-40de-a6c1-3974b92d15ec/financial-invoices-late-payments",
        "coverage": {"start": "2023-04-01", "end": "2026-05-31", "basis": "official resource list"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "downloaded_and_audited_late_only", "actual_payment_semantics": "cleared/actual payment date",
        "population": "one buyer and late invoices only", "license": "not set on catalog record",
        "decision": "late_only_augmentation_built",
        "reason": "Full schema in newer workbooks; kept separate because outcome selection and short coverage block representative pooling.",
    },
    {
        "country": "GB", "name": "Registers of Scotland late-payment FOI",
        "url": "https://www.ros.gov.uk/about/publications/freedom-of-information-releases/2025/foi-release-late-payments",
        "coverage": {"start": "2019-04-01", "end": "2025-11-30", "basis": "official FOI response"},
        "schema": schema(invoice_id=False, seller_id=False, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "public_attachment", "actual_payment_semantics": "payment date",
        "population": "one buyer; only invoices paid after 30 days",
        "license": "site copyright/FOI reuse terms require confirmation",
        "decision": "reject_bias_identity",
        "reason": "Timeline aligns, but an outcome-conditioned sample cannot train a representative lateness model.",
    },
    {
        "country": "CL", "name": "SIGFE supplier-invoice report",
        "url": "https://www.dipres.gob.cl/590/articles-276267_doc_pdf.pdf",
        "coverage": {"start": "2020-01-01", "end": "2026-01-01", "basis": "report documentation, not a public row archive"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=None,
                         amount=True, currency=None),
        "row_access": "documentation_only", "actual_payment_semantics": "payment-state fields documented; actual date not verified",
        "population": "central government operational report",
        "license": "documentation public; transaction-row reuse not established",
        "decision": "reject_no_public_rows",
        "reason": "No reusable national row export with verified actual payment date was found.",
    },
    {
        "country": "SK", "name": "Central Register of Contracts paid invoices",
        "url": "https://slovak-egov.atlassian.net/wiki/spaces/opendata/pages/20056665/Fakt%2Bry",
        "coverage": {"start": None, "end": "2026-09-30", "basis": "sampled packages; current sample only 2026"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=True,
                         amount=True, currency=True),
        "row_access": "sample_downloaded_packages_marked_deleted", "actual_payment_semantics": "first payment date for paid invoices",
        "population": "paid-only; partial payments reduced to first date plus full invoice amount",
        "license": "CC BY 4.0 in sampled package metadata",
        "decision": "reject_schema_and_timeline", "reason": "No issue/due dates and no verified 2021-2025 snapshot.",
    },
    {
        "country": "AU", "name": "ACT Notifiable Invoices Register",
        "url": "https://www.procurement.act.gov.au/registers/act-government-notifiable-invoices-register",
        "coverage": {"start": "2019-01-01", "end": "2026-09-18", "basis": "audited local snapshot"},
        "schema": schema(invoice_id=False, seller_id=True, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=True,
                         amount=True, currency=True),
        "row_access": "downloaded_and_audited", "actual_payment_semantics": "official payment date",
        "population": "paid notifiable invoices above a publication threshold",
        "license": "CC BY 4.0 in captured official metadata",
        "decision": "excluded_receipt_to_payment",
        "reason": "Removed from T1 because it cannot label issue-to-payment or lateness against due date.",
    },
    {
        "country": "IT", "name": "Tuscany/Vicopisano supplier payment timeliness",
        "url": "https://dati.toscana.it/it/dataset/tempestivita-dei-pagamenti-ai-fornitori",
        "coverage": {"start": "2018-01-01", "end": "2020-12-31", "basis": "portal resources"},
        "schema": schema(invoice_id=True, seller_id=None, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=True,
                         amount=True, currency=True),
        "row_access": "public_resources", "actual_payment_semantics": "payment date",
        "population": "one municipality", "license": "resource-specific terms require verification",
        "decision": "reject_schema_and_timeline",
        "reason": "Receipt/posting-style timing, one buyer, and coverage ends before the common window.",
    },
    {
        "country": "SE", "name": "National supplier-ledger open-data specification",
        "url": "https://lankadedata.se/spec/leverantorsreskontra/1.1/",
        "coverage": {"start": None, "end": None, "basis": "schema specification"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=True, currency=True),
        "row_access": "publisher_specific", "actual_payment_semantics": "not in common specification",
        "population": "multiple municipalities using a common AP vocabulary",
        "license": "publisher-specific", "decision": "reject_missing_target_dates",
        "reason": "The common specification omits issue, due, and actual payment dates required by T1.",
    },
    {
        "country": "FI", "name": "Tutkihankintoja purchase invoices",
        "url": "https://avoindata.suomi.fi/data/en_GB/dataset/tutkihankintoja-data",
        "coverage": {"start": "2016-01-01", "end": "2026-01-01", "basis": "official catalog"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=True, currency=True),
        "row_access": "public_download", "actual_payment_semantics": "posting/entry date only",
        "population": "central-government multi-buyer spend", "license": "CC BY 4.0",
        "decision": "reject_missing_target_dates",
        "reason": "Strong identities and coverage, but no issue/due/actual-payment event.",
    },
    {
        "country": "FR", "name": "Territorial-authority payment delays",
        "url": "https://www.data.gouv.fr/datasets/delais-de-paiement-2024-des-collectivites-territoriales-1",
        "coverage": {"start": "2024-01-01", "end": "2024-12-31", "basis": "official annual release"},
        "schema": schema(invoice_id=False, seller_id=False, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=False, currency=True),
        "row_access": "public_download", "actual_payment_semantics": "annual mean only",
        "population": "aggregate per public budget", "license": "Licence Ouverte 2.0",
        "decision": "reject_aggregate", "reason": "Not invoice-level data.",
    },
    {
        "country": "ES", "name": "FACe invoice reporting",
        "url": "https://datos.gob.es/es/catalogo/e05068901-face-organismos-que-han-recibido-facturas-en-face-acumulado",
        "coverage": {"start": None, "end": "2026-01-01", "basis": "official catalog"},
        "schema": schema(invoice_id=False, seller_id=False, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=False, currency=True),
        "row_access": "public_aggregate", "actual_payment_semantics": "counts/reporting only",
        "population": "organization-level FACe reports", "license": "portal terms",
        "decision": "reject_aggregate",
        "reason": "Public resources are counts/compliance reports, not invoice-payment rows.",
    },
    {
        "country": "NZ", "name": "Government agency invoice payment times",
        "url": "https://www.mbie.govt.nz/about/open-government-and-official-information/release-of-information/government-agencies-invoice-payment-times",
        "coverage": {"start": "2020-01-01", "end": "2026-01-01", "basis": "official quarterly series"},
        "schema": schema(invoice_id=False, seller_id=False, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=False, currency=True),
        "row_access": "public_aggregate", "actual_payment_semantics": "percentages and counts",
        "population": "quarterly agency performance", "license": "official publication",
        "decision": "reject_aggregate", "reason": "No supplier or invoice rows.",
    },
    {
        "country": "CA", "name": "British Columbia supplier payments",
        "url": "https://open.canada.ca/data/en/dataset/f6bad1d5-d1dc-4fdd-a076-650f55cc3fbc",
        "coverage": {"start": "2007-01-01", "end": "2026-03-31", "basis": "official annual resources"},
        "schema": schema(invoice_id=False, seller_id=True, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=True, currency=True),
        "row_access": "public_annual_downloads", "actual_payment_semantics": "annual payee totals",
        "population": "payees receiving at least the publication threshold",
        "license": "Open Government Licence - British Columbia",
        "decision": "reject_aggregate",
        "reason": "Long aligned timeline, but annual supplier totals cannot form invoice labels.",
    },
    {
        "country": "UY", "name": "SICE invoice module",
        "url": "https://www.gub.uy/agencia-reguladora-compras-estatales/sites/agencia-reguladora-compras-estatales/files/2024-07/16.%20Facturas.pdf",
        "coverage": {"start": None, "end": "2024-07-01", "basis": "official user manual"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=None,
                         amount=True, currency=None),
        "row_access": "documentation_only", "actual_payment_semantics": "not verified in a public row export",
        "population": "government procurement system", "license": "manual public; row-data reuse unknown",
        "decision": "reject_no_public_rows",
        "reason": "Operational schema is close, but no reusable multi-year invoice/payment export was verified.",
    },
    {
        "country": "PL", "name": "Payment-practice reports",
        "url": "https://www.gov.pl/web/rozwoj-technologia/sprawozdania-o-stosowanych-terminach-zaplaty",
        "coverage": {"start": "2020-01-01", "end": "2025-12-31", "basis": "official annual reports"},
        "schema": schema(invoice_id=False, seller_id=False, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=True, currency=True),
        "row_access": "public_reports", "actual_payment_semantics": "bucketed/aggregate practices",
        "population": "large-entity annual reporting", "license": "official publication",
        "decision": "reject_aggregate",
        "reason": "Timeline aligns but the reporting unit is an entity/year, not an invoice.",
    },
    {
        "country": "ZA", "name": "National Treasury late/non-payment reports",
        "url": "https://www.treasury.gov.za/legislation/pfma/Compliance%20on%20Payment%20of%20Suppliers/Non-compliance%20report-Q2-2022-2023.pdf",
        "coverage": {"start": "2022-04-01", "end": "2023-03-31", "basis": "official compliance report"},
        "schema": schema(invoice_id=False, seller_id=False, buyer_id=True,
                         issue_date=False, due_date=False, payment_date=False,
                         amount=True, currency=True),
        "row_access": "public_report", "actual_payment_semantics": "late/unpaid counts and reasons",
        "population": "government compliance aggregates", "license": "official publication",
        "decision": "reject_aggregate", "reason": "No invoice-level identifiers or event dates.",
    },
    {
        "country": "IN", "name": "Government Open Data portal search",
        "url": "https://www.data.gov.in/",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official catalog search"},
        "schema": schema(), "row_access": "no_matching_public_registry_verified",
        "actual_payment_semantics": "unknown", "population": "catalog-level search only",
        "license": "Government Open Data License applies to published resources",
        "decision": "no_qualifying_source_found",
        "reason": "No public multi-buyer registry matching the complete contract and timeline was verified.",
    },
    {
        "country": "NL", "name": "Central-government e-invoicing infrastructure",
        "url": "https://business.gov.nl/regulations/invoice-requirements/",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official requirements page"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=None, payment_date=False,
                         amount=True, currency=True),
        "row_access": "no_public_transaction_rows", "actual_payment_semantics": "not published",
        "population": "infrastructure/requirements, not an open registry",
        "license": "not applicable to transaction rows", "decision": "reject_no_public_rows",
        "reason": "Mandatory B2G e-invoicing does not make invoice/payment microdata public.",
    },
    {
        "country": "GB", "name": "Sustainable Development Commission transaction return",
        "url": "https://www.data.gov.uk/dataset/83a446c1-31bd-4328-80f6-3ecaf83d2a78/financial-transactions-data-sdc",
        "coverage": {"start": "2010-10-01", "end": "2010-10-31", "basis": "official CSV preview and dataset record"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "public_historical_csv_not_audited",
        "actual_payment_semantics": "Invoice Paid Date",
        "population": "one defunct public body; transaction return with supplier terms",
        "license": "official data.gov.uk record; exact resource terms require capture",
        "decision": "reject_common_timeline",
        "reason": "Rare complete public schema, but it is a one-month 2010 return and cannot join the 2021-2025 pool.",
    },
    {
        "country": "GB", "name": "Staffordshire Police late-payment FOI",
        "url": "https://www.staffordshire.police.uk/SysSiteAssets/foi-media/staffordshire/2026-published-foi-requests/january/foi-22269-refinement-of-foi-21498-failed-supplier-payments.pdf",
        "coverage": {"start": "2023-07-01", "end": "2025-12-19", "basis": "official FOI response; exact attachment end pending audit"},
        "schema": schema(invoice_id=None, seller_id=None, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=None),
        "row_access": "official_attachment_named_url_not_resolved",
        "actual_payment_semantics": "payment date in a late-payment extract",
        "population": "one police authority; late payments only, including disputed invoices and credit notes",
        "license": "publication-scheme reuse permits accurate attribution; attachment-specific terms pending",
        "decision": "priority_late_only_download_candidate",
        "reason": "Modern due/payment fields may expand stress data, but identity, currency, attachment access and row semantics need audit.",
    },
    {
        "country": "PE", "name": "SUSALUD private-health billing register",
        "url": "https://www.datosabiertos.gob.pe/dataset/registro-de-datos-de-facturaci%C3%B3n-de-la-cobertura-prestacional-de-salud-del-sector-privado",
        "coverage": {"start": "2025-09-01", "end": "2025-11-30", "basis": "official monthly resource list inspected"},
        "schema": schema(invoice_id=None, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=False, payment_date=False,
                         amount=True, currency=None),
        "row_access": "public_monthly_csv", "actual_payment_semantics": "liquidation date, not verified cash payment",
        "population": "private health providers billing insurers; pseudonymous party identifiers",
        "license": "official Peru open-data portal terms",
        "decision": "reject_missing_actual_payment_date",
        "reason": "Useful multi-party near-match, but it lacks due date and actual cash-payment date.",
    },
    {
        "country": "NG", "name": "Nigeria national e-invoice schema",
        "url": "https://einvoice.nrs.gov.ng/docs/system-integrator/invoice-schema",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official current schema documentation; no public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=False,
                         amount=True, currency=True),
        "row_access": "schema_only_no_public_transactions",
        "actual_payment_semantics": "payment status is documented, not an actual payment date",
        "population": "national e-invoicing infrastructure, not an open transaction registry",
        "license": "not applicable to private transaction rows",
        "decision": "reject_no_public_rows",
        "reason": "Schema is close, but payment_date is absent and invoice microdata are not public.",
    },
    {
        "country": "SA", "name": "SAMA ESAL e-invoicing and reconciliation",
        "url": "https://sama.gov.sa/en-US/payment/Pages/ESAL.aspx",
        "coverage": {"start": "2019-01-01", "end": "2026-10-22", "basis": "official service history, not public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=None, due_date=True, payment_date=None,
                         amount=True, currency=None),
        "row_access": "participant_portal_only",
        "actual_payment_semantics": "platform reconciles payments but public microdata are unavailable",
        "population": "business invoice network across buyers and suppliers",
        "license": "not applicable to participant transaction rows",
        "decision": "reject_no_public_rows",
        "reason": "A strong partner-export lead, not a public dataset usable by the student team.",
    },
    {
        "country": "AE", "name": "UAE federal supplier-services invoice portal",
        "url": "https://mof.gov.ae/wp-content/uploads/2022/10/MoF_DPP_User-Manual_Supplier_Services_ENG.pdf",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official portal manual; no public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "authenticated_supplier_portal_only",
        "actual_payment_semantics": "portal exposes payment date to the authenticated supplier",
        "population": "federal supplier invoices; user-scoped access",
        "license": "not applicable to authenticated transaction rows",
        "decision": "reject_no_public_rows",
        "reason": "Complete operational schema exists, but there is no open cross-supplier transaction export.",
    },
    {
        "country": "EE", "name": "Estonia e-Financials payment report",
        "url": "https://abiinfo.rik.ee/en/e-financials/reports/incoming-and-outgoing-payments-report",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official product documentation; no public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=None),
        "row_access": "account_holder_report_only",
        "actual_payment_semantics": "settlement and received-payment dates in detailed report",
        "population": "each accounting user's own purchase/sales invoices",
        "license": "not applicable to account-holder transaction rows",
        "decision": "reject_no_public_rows",
        "reason": "Useful export schema for a partner, but not a public registry and currency is not documented on the page.",
    },
    {
        "country": "DK", "name": "Danish public-sector OIOUBL invoicing",
        "url": "https://www.fmi.dk/en/supplier/selected-requirements/invoicing-and-payment/",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official invoicing requirements; no public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=None, payment_date=False,
                         amount=True, currency=True),
        "row_access": "infrastructure_only_no_public_transactions",
        "actual_payment_semantics": "not published",
        "population": "public-sector e-invoices remain inside agency finance systems",
        "license": "not applicable to private invoice rows",
        "decision": "reject_no_public_rows",
        "reason": "Mandatory structured invoicing does not expose linked payment outcomes as open data.",
    },
    {
        "country": "NO", "name": "Norwegian EHF public-sector invoice infrastructure",
        "url": "https://www.anskaffelser.no/veileder-datadrevne-anskaffelser/4-data-i-oppfolgingsfasen",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official procurement guidance; no national public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=None,
                         amount=True, currency=True),
        "row_access": "agency_internal_finance_systems",
        "actual_payment_semantics": "payment data exist locally but are not a public national registry",
        "population": "public agencies using EHF/Peppol",
        "license": "not applicable to agency transaction rows",
        "decision": "reject_no_public_rows",
        "reason": "Official guidance confirms structured invoice/payment data exist inside agencies, not as downloadable microdata.",
    },
    {
        "country": "SG", "name": "Singapore Vendors@Gov paid-transactions report",
        "url": "https://www.vendors.gov.sg/doc/View_and_Retrieve_Paidtransactions.pdf?ver=1.1",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official portal guide; user-scoped retention and no public rows"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=True,
                         amount=True, currency=True),
        "row_access": "authenticated_vendor_portal_only",
        "actual_payment_semantics": "remittance advice exposes actual payment date",
        "population": "government suppliers see their own invoices and paid transactions",
        "license": "not applicable to authenticated transaction rows",
        "decision": "reject_no_public_rows",
        "reason": "Complete operational fields, but no open multi-vendor export and historical retrieval is constrained.",
    },
    {
        "country": "BE", "name": "Belgian Peppol public e-invoicing infrastructure",
        "url": "https://efacture.belgium.be/fr/FAQ/questions-specifiques-sur-la-facturation-electronique",
        "coverage": {"start": None, "end": "2026-10-22", "basis": "official service FAQ; no public row coverage"},
        "schema": schema(invoice_id=True, seller_id=True, buyer_id=True,
                         issue_date=True, due_date=True, payment_date=False,
                         amount=True, currency=True),
        "row_access": "infrastructure_only_no_public_transactions",
        "actual_payment_semantics": "not part of the public invoice feed",
        "population": "Peppol invoice exchange, not an open transaction registry",
        "license": "not applicable to private invoice rows",
        "decision": "reject_no_public_rows",
        "reason": "The standard transports invoices but does not publish linked payment outcomes.",
    },
]


def covers_pool_window(item: dict) -> bool:
    start, end = item["coverage"]["start"], item["coverage"]["end"]
    return bool(start and end and start <= POOL_WINDOW["start"] and end >= POOL_WINDOW["end"])


def complete_schema(item: dict) -> bool:
    return all(item["schema"].get(field) is True for field in REQUIRED_FIELDS)


def probe(url: str) -> dict:
    request = urllib.request.Request(
        url, headers={"User-Agent": "FinanceProject-T1-IssuePaymentRegistryAudit/2.0",
                      "Range": f"bytes=0-{SAMPLE_LIMIT - 1}"})
    checked = datetime.now(timezone.utc).isoformat()
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = response.read(SAMPLE_LIMIT)
            return {"status": response.status, "final_url": response.url,
                    "content_type": response.headers.get("Content-Type"),
                    "declared_content_length": response.headers.get("Content-Length"),
                    "sample_bytes": len(payload),
                    "sample_sha256": hashlib.sha256(payload).hexdigest(),
                    "checked_at_utc": checked}
    except urllib.error.HTTPError as exc:
        return {"status": exc.code, "final_url": exc.url, "error": str(exc),
                "checked_at_utc": checked}
    except (urllib.error.URLError, TimeoutError) as exc:
        return {"status": None, "error": str(exc), "checked_at_utc": checked}


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true",
                        help="Validate existing evidence without network requests")
    parser.add_argument("--output", type=Path, default=(
        ROOT / "research/references/data-checks/t1/t1_global_b2g_source_research.json"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    spec_hash = hashlib.sha256(json.dumps(
        SOURCES, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
    if args.offline:
        existing = json.loads(args.output.read_text(encoding="utf-8"))
        if existing["spec_sha256"] != spec_hash:
            raise ValueError("Evidence was created from a different source registry")
        print(json.dumps(existing["summary"], ensure_ascii=False, indent=2))
        return

    with ThreadPoolExecutor(max_workers=8) as pool:
        probes = list(pool.map(lambda item: probe(item["url"]), SOURCES))
    results = []
    for source, access in zip(SOURCES, probes):
        results.append({
            **source,
            "complete_required_schema": complete_schema(source),
            "covers_common_pool_window": covers_pool_window(source),
            "strict_pool_ready": (
                source["row_access"] == "downloaded_and_audited"
                and complete_schema(source)
                and covers_pool_window(source)
            ),
            "access_probe": access,
        })
    decisions = {}
    for item in results:
        decisions[item["decision"]] = decisions.get(item["decision"], 0) + 1
    value = {
        "research_date": CHECKED_ON,
        "scope": "public B2G registries screened for issue/due/actual-payment target",
        "spec_sha256": spec_hash,
        "pool_contract": {
            "common_window": POOL_WINDOW,
            "required_fields": list(REQUIRED_FIELDS),
            "required_grain": "one normalized invoice-payment outcome after collapsing source line items",
            "promotion_rule": "complete schema + full 2021-2025 coverage + row audit + reuse terms",
            "split_if_promoted": {
                "train": "2021-01-01..2023-12-31",
                "validation": "2024-01-01..2024-12-31",
                "test": "2025-01-01..2025-12-31",
            },
        },
        "summary": {
            "countries": len({item["country"] for item in results}),
            "sources": len(results), "decisions": decisions,
            "complete_schema_sources": [item["name"] for item in results if item["complete_required_schema"]],
            "complete_schema_and_timeline": [item["name"] for item in results
                                             if item["complete_required_schema"]
                                             and item["covers_common_pool_window"]],
            "strict_pool_ready": [item["name"] for item in results if item["strict_pool_ready"]],
            "next_download_audit": ["Los Angeles Checkbook L.A."],
        },
        "sources": results,
        "method_limits": [
            "HTTP success proves reachability, not row-level quality, coverage, or payment semantics.",
            "Only an actual-payment event satisfies payment_date; status, authorization, liquidation, posting, and estimated dates do not.",
            "The common window is the intersection for future pooling, not proof every candidate has usable rows in every year.",
            "Late-only/thresholded publications are rejected from representative training even when visible columns are complete.",
            "Country and source remain provenance/evaluation groups after pooling; local amounts need an explicit FX design.",
            "No model was trained and no new source was added to the normalized dataset by this screening run.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(value["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
