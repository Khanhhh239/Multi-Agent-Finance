"""Build a late-only issue-to-payment augmentation from official Barnet workbooks.

The output deliberately stays separate from the representative Czech panel.  Only
rows anchored in the primary training period may augment model fitting; later rows
are auxiliary stress checks and never part of primary validation/test metrics.
"""

from __future__ import annotations

import argparse
import csv
from collections import Counter
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

try:
    from scripts.data_audit.build_t1_public_b2g_dataset import (
        OUTPUT_FIELDS, digest_file, parse_amount, row_record, write_json, write_rows,
    )
except ModuleNotFoundError:  # Direct execution sets sys.path to scripts/data_audit.
    from build_t1_public_b2g_dataset import (
        OUTPUT_FIELDS, digest_file, parse_amount, row_record, write_json, write_rows,
    )


ROOT = Path(__file__).resolve().parents[2]
SNAPSHOT = "2026-10-22"
RAW_DIR = ROOT / "data/T1/raw/late_only_augmentation" / SNAPSHOT
OUTPUT = ROOT / "data/T1/interim/public_b2g_v01/late_only_augmentation.csv"
EVIDENCE = ROOT / "research/references/data-checks/t1/t1_late_only_augmentation.json"
SOURCE_PAGE = "https://www.data.gov.uk/dataset/721ea736-1fee-40de-a6c1-3974b92d15ec/financial-invoices-late-payments"
FILES = {
    "barnet_2023_2024.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/v11/"
        "Late%20Payment%20of%20Finance%20Invoices%2023-24.xlsx"
    ),
    "barnet_2024_2025.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/mty/"
        "Late%20payment%20of%20finance%20invoice%20from%2001.04.24-30.05.25.xlsx"
    ),
    "barnet_2025.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/w3g/"
        "Late%20Payment%20of%20Finance%20Invoice%2001.06.25%20-%2030.11.25.xlsx"
    ),
}
MODERN_REQUIRED = {
    "Supplier Number", "Invoice Number", "Invoice Amount", "Fully Paid",
    "Invoice Date", "Due Date (Last)", "Payment Date (Last)",
}


def build_manifest(offline: bool) -> dict:
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    manifest_path = RAW_DIR / "source_manifest.json"
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        for item in manifest["files"]:
            path = RAW_DIR / item["file"]
            if path.stat().st_size != item["bytes"] or digest_file(path) != item["sha256"]:
                raise ValueError(f"Barnet raw snapshot changed: {path}")
        return manifest
    files = []
    for filename, url in FILES.items():
        path = RAW_DIR / filename
        status = "preexisting_validated"
        if not path.exists():
            if offline:
                raise ValueError(f"Offline mode requires {path}")
            request = urllib.request.Request(
                url, headers={"User-Agent": "FinanceProject-T1-LateAugmentation/1.0"})
            with urllib.request.urlopen(request, timeout=120) as response:
                path.write_bytes(response.read())
                status = response.status
        if not zipfile.is_zipfile(path):
            raise ValueError(f"Downloaded resource is not an XLSX workbook: {path}")
        files.append({
            "file": filename, "url": url, "status": status,
            "bytes": path.stat().st_size, "sha256": digest_file(path),
        })
    manifest = {
        "snapshot": SNAPSHOT, "source_page": SOURCE_PAGE,
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "files": files,
        "license_note": "Dataset record has no explicit licence; data.gov.uk page footer states OGL except where otherwise stated. Confirm before redistribution.",
    }
    write_json(manifest_path, manifest)
    return manifest


def column_index(reference: str) -> int:
    letters = re.match(r"[A-Z]+", reference).group(0)
    value = 0
    for char in letters:
        value = value * 26 + ord(char) - 64
    return value - 1


def read_first_sheet(path: Path) -> tuple[list[str], list[dict]]:
    ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    with zipfile.ZipFile(path) as archive:
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(node.text or "" for node in item.iter(ns + "t"))
                      for item in root.findall(ns + "si")]
        sheet = ET.fromstring(archive.read("xl/worksheets/sheet1.xml"))
    matrix = []
    for row in sheet.find(ns + "sheetData").findall(ns + "row"):
        values = {}
        for cell in row.findall(ns + "c"):
            value_node = cell.find(ns + "v")
            value = "" if value_node is None else value_node.text or ""
            if cell.get("t") == "s" and value:
                value = shared[int(value)]
            values[column_index(cell.get("r"))] = value
        matrix.append(values)
    if not matrix:
        return [], []
    width = max(matrix[0], default=-1) + 1
    headers = [matrix[0].get(index, "").strip() for index in range(width)]
    rows = [{header: values.get(index, "") for index, header in enumerate(headers) if header}
            for values in matrix[1:]]
    return headers, rows


def excel_date(value) -> date | None:
    text = str(value or "").strip()
    if not text or text == "0":
        return None
    if re.fullmatch(r"\d{8}", text):
        try:
            return datetime.strptime(text, "%Y%m%d").date()
        except ValueError:
            return None
    try:
        number = float(text)
        if 30_000 <= number <= 60_000:
            return date(1899, 12, 30) + timedelta(days=int(number))
    except ValueError:
        pass
    for pattern in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(text[:10], pattern).date()
        except ValueError:
            continue
    return None


def normalize_modern_row(row: dict) -> tuple[dict | None, str | None]:
    seller = str(row.get("Supplier Number") or "").strip()
    invoice = str(row.get("Invoice Number") or "").strip()
    issue = excel_date(row.get("Invoice Date"))
    due = excel_date(row.get("Due Date (Last)"))
    paid = excel_date(row.get("Payment Date (Last)"))
    amount = parse_amount(row.get("Invoice Amount"))
    if str(row.get("Fully Paid") or "").strip().upper() != "Y":
        return None, "not_fully_paid"
    if not seller or not invoice:
        return None, "missing_stable_key"
    if not issue or not due or not paid:
        return None, "missing_or_invalid_date"
    if not (date(2021, 1, 1) <= issue <= date(2025, 12, 31)
            and issue <= paid <= date(2025, 12, 31)):
        return None, "outside_common_window_or_order"
    if amount is None or amount <= Decimal("0"):
        return None, "nonpositive_or_invalid_amount"
    normalized = row_record(
        lane="issue_to_payment", country="GB", source="GB_BARNET_LATE_ONLY",
        buyer="London Borough of Barnet", seller=f"supplier:{seller}",
        invoice=invoice, issue=issue,
        received=excel_date(row.get("Invoice Received Date")), due=due,
        paid=paid, amount=amount, currency="GBP")
    normalized["panel_eligible_train"] = "False"
    return normalized, None


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--evidence", type=Path, default=EVIDENCE)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest = build_manifest(args.offline)
    accepted, seen = [], set()
    audits = {}
    for filename in FILES:
        headers, rows = read_first_sheet(RAW_DIR / filename)
        rejected = Counter()
        if not MODERN_REQUIRED.issubset(headers):
            audits[filename] = {
                "source_rows": len(rows), "accepted_rows": 0,
                "decision": "excluded_ambiguous_legacy_export",
                "reason": "The 200-column ledger export does not expose the same audited due-date semantics as later workbooks.",
                "columns": len(headers),
            }
            continue
        for row in rows:
            normalized, reason = normalize_modern_row(row)
            if reason:
                rejected[reason] += 1
                continue
            key = normalized["record_id"]
            if key in seen:
                rejected["duplicate_normalized_record"] += 1
                continue
            seen.add(key)
            accepted.append(normalized)
        audits[filename] = {
            "source_rows": len(rows), "accepted_rows": len(accepted) - sum(
                item.get("accepted_rows", 0) for item in audits.values()),
            "decision": "included_late_only_augmentation",
            "columns": len(headers), "rejected": dict(rejected),
        }
    accepted.sort(key=lambda row: (row["anchor_date"], row["record_id"]))
    write_rows(args.output, accepted)
    split_counts = Counter(row["split"] for row in accepted)
    late_counts = Counter("late" if int(row["days_late"]) > 0 else "not_late_by_published_due"
                          for row in accepted)
    evidence = {
        "dataset": "t1_late_only_augmentation_v01", "built_on": SNAPSHOT,
        "raw_manifest": manifest, "audit": audits,
        "contract": {
            "schema": OUTPUT_FIELDS, "common_window": ["2021-01-01", "2025-12-31"],
            "sampling_policy": "outcome-selected late-payment publication",
            "training_rule": "only split=train rows may augment training; never tune or report primary metrics on this file",
            "identity_rule": "source supplier number and invoice number are hashed; names/addresses are omitted",
        },
        "summary": {
            "rows": len(accepted), "distinct_sellers": len({row["seller_id"] for row in accepted}),
            "distinct_buyers": len({row["buyer_id"] for row in accepted}),
            "split_counts": dict(sorted(split_counts.items())),
            "published_due_outcomes": dict(sorted(late_counts.items())),
            "anchor_date_min": min((row["anchor_date"] for row in accepted), default=None),
            "anchor_date_max": max((row["anchor_date"] for row in accepted), default=None),
        },
        "output": {"file": args.output.name, "bytes": args.output.stat().st_size,
                   "sha256": digest_file(args.output)},
        "limitations": [
            "Barnet publishes an outcome-selected late-payment register, not a random sample of all invoices.",
            "The source represents one public buyer and must not be used as evidence of multi-buyer customer behaviour.",
            "The 2023-24 ledger-shaped workbook is retained in raw evidence but excluded because its due-date semantics differ from later workbooks.",
            "Rows not late against the workbook's published due date can still appear because publication lateness is defined from invoice receipt under the source policy.",
            "The dataset catalog record does not set an explicit licence; redistribution terms need confirmation before packaging data.",
            "No model was trained by this build.",
        ],
    }
    write_json(args.evidence, evidence)
    print(json.dumps(evidence["summary"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
