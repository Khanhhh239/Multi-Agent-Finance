"""Build the privacy-reduced issue-to-payment public B2G dataset for T1.

The only target in this build is invoice issue date to actual payment date, with
a contractual due date.  Receipt-to-payment sources remain in research evidence
but are deliberately excluded from normalized outputs and training cohorts.

Only paid observations are available in these publications.  The outputs therefore
cannot be used to claim validation of an open-invoice survival model.  Raw snapshots
and row-level outputs live below ignored ``data/T1`` directories; the committed JSON
contains aggregate evidence only and no supplier names or public identifiers.
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import shutil
import urllib.request


ROOT = Path(__file__).resolve().parents[2]
RESEARCH_DATE = "2026-10-22"
WINDOW_START = date(2019, 1, 1)
TRAIN_END = date(2023, 12, 31)
VALIDATION_END = date(2024, 12, 31)
TEST_END = date(2025, 12, 31)
WINDOW_END = date(2026, 9, 30)
MZP_BASE = "https://data.mzp.cz/datasets/dataset/jasu/"
MZP_SOURCES = {
    "CZ_MZP": "mzp_uhrazene_faktury.csv",
    "CZ_AOPK": "aopk_uhrazene_faktury.csv",
    "CZ_SJCR": "sjcr_uhrazene_faktury.csv",
    "CZ_SFZP": "sfzp_uhrazene_faktury.csv",
    "CZ_CGS": "cgs_uhrazene_faktury.csv",
    "CZ_CIZP": "cizp_uhrazene_faktury.csv",
    "CZ_CENIA": "cenia_uhrazene_faktury.csv",
}
MZP_FIELDS = {
    "cislo_smlouvy", "cislo_objednavky", "dodavatel", "ico",
    "cislo_faktury", "datum_vystaveni", "datum_prijeti",
    "datum_splatnosti", "datum_uhrady", "celkova_castka",
    "castka_polozky", "mena", "ucel_platby", "polozka_rozpoctu",
    "nazev_polozky_rozpoctu", "kapitola", "nazev_kapitoly",
}
OUTPUT_FIELDS = [
    "record_id", "lane", "country", "source", "buyer_id", "seller_id",
    "invoice_id", "anchor_date", "issue_date", "received_date", "due_date",
    "payment_date", "amount_local", "currency", "target_days", "days_late",
    "split", "panel_eligible_train",
]


def digest_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def digest_file(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def token(namespace: str, value: str, length: int = 24) -> str:
    payload = f"t1-public-b2g-v01|{namespace}|{value}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:length]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def parse_date(value) -> date | None:
    text = str(value or "").strip()[:10]
    try:
        return date.fromisoformat(text)
    except ValueError:
        return None


def parse_amount(value) -> Decimal | None:
    text = str(value or "").strip().replace("\u00a0", "").replace(" ", "")
    if not text:
        return None
    if text.count(",") == 1 and "." not in text:
        text = text.replace(",", ".")
    try:
        return Decimal(text)
    except InvalidOperation:
        return None


def normalize_business_id(value: str, minimum: int = 6, maximum: int = 14) -> str | None:
    digits = re.sub(r"\D", "", str(value or ""))
    if minimum <= len(digits) <= maximum and any(char != "0" for char in digits):
        return digits
    return None


def split_for(anchor: date) -> str:
    if anchor <= TRAIN_END:
        return "train"
    if anchor <= VALIDATION_END:
        return "validation"
    if anchor <= TEST_END:
        return "test"
    return "external_2026"


def valid_window(anchor: date, paid: date) -> bool:
    return WINDOW_START <= anchor <= WINDOW_END and anchor <= paid <= WINDOW_END


def row_record(*, lane: str, country: str, source: str, buyer: str, seller: str,
               invoice: str, issue: date | None, received: date | None,
               due: date | None, paid: date, amount: Decimal, currency: str) -> dict:
    if lane != "issue_to_payment" or issue is None or due is None:
        raise ValueError("T1 public B2G build accepts issue-to-payment rows with due_date only")
    anchor = issue
    identity = "|".join((source, buyer, seller, invoice, anchor.isoformat(), str(amount)))
    return {
        "record_id": token("record", identity),
        "lane": lane,
        "country": country,
        "source": source,
        "buyer_id": token(f"{country}:buyer", buyer),
        "seller_id": token(f"{country}:seller", seller),
        "invoice_id": token(f"{source}:invoice", identity),
        "anchor_date": anchor.isoformat(),
        "issue_date": issue.isoformat() if issue else "",
        "received_date": received.isoformat() if received else "",
        "due_date": due.isoformat() if due else "",
        "payment_date": paid.isoformat(),
        "amount_local": format(amount, "f"),
        "currency": currency.upper(),
        "target_days": str((paid - anchor).days),
        "days_late": str((paid - due).days) if due else "",
        "split": split_for(anchor),
        "panel_eligible_train": "False",
    }


def build_mzp_snapshot(folder: Path, offline: bool) -> dict:
    manifest_path = folder / "source_manifest.json"
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        for item in manifest["files"]:
            path = folder / item["file"]
            if path.stat().st_size != item["bytes"] or digest_file(path) != item["sha256"]:
                raise ValueError(f"MZP snapshot changed: {path}")
        return manifest
    if offline:
        raise ValueError("Offline mode requires an existing MZP snapshot")
    if folder.exists() and any(folder.iterdir()):
        raise ValueError("MZP snapshot directory is non-empty but has no manifest")
    folder.mkdir(parents=True, exist_ok=True)
    files = []
    for source, filename in MZP_SOURCES.items():
        url = MZP_BASE + filename
        target = folder / filename
        request = urllib.request.Request(
            url, headers={"User-Agent": "FinanceProject-T1-PublicB2G/1.0"})
        with urllib.request.urlopen(request, timeout=180) as response, target.open("wb") as output:
            shutil.copyfileobj(response, output)
            status = response.status
        files.append({
            "source": source,
            "file": filename,
            "url": url,
            "status": status,
            "bytes": target.stat().st_size,
            "sha256": digest_file(target),
            "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        })
    manifest = {
        "snapshot_date": RESEARCH_DATE,
        "files": files,
        "license": {
            "value": "CC0",
            "catalog_predicate": "http://www.w3.org/2004/02/skos/core#narrowMatch",
            "catalog_value": "http://publications.europa.eu/resource/authority/licence/CC0",
            "verified_at": "https://data.gov.cz/sparql",
            "checked_on": RESEARCH_DATE,
        },
    }
    write_json(manifest_path, manifest)
    return manifest


def load_mzp(folder: Path) -> tuple[list[dict], dict]:
    output = []
    evidence = {}
    for source, filename in MZP_SOURCES.items():
        raw_rows = 0
        groups = defaultdict(list)
        rejected = Counter()
        with (folder / filename).open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if set(reader.fieldnames or []) != MZP_FIELDS:
                raise ValueError(f"Unexpected MZP fields in {filename}: {reader.fieldnames}")
            for row in reader:
                raw_rows += 1
                seller = normalize_business_id(row["ico"], 6, 8)
                invoice = row["cislo_faktury"].strip()
                issue = parse_date(row["datum_vystaveni"])
                received = parse_date(row["datum_prijeti"])
                due = parse_date(row["datum_splatnosti"])
                paid = parse_date(row["datum_uhrady"])
                amount = parse_amount(row["celkova_castka"])
                currency = row["mena"].strip().upper()
                if not seller or not invoice:
                    rejected["missing_stable_key"] += 1
                    continue
                if not all((issue, received, due, paid)):
                    rejected["missing_or_invalid_date"] += 1
                    continue
                assert issue and received and due and paid
                if not (issue <= received <= paid and issue <= due):
                    rejected["date_order"] += 1
                    continue
                if amount is None or amount <= 0:
                    rejected["nonpositive_or_invalid_amount"] += 1
                    continue
                if not re.fullmatch(r"[A-Z]{3}", currency):
                    rejected["invalid_currency"] += 1
                    continue
                if not valid_window(issue, paid):
                    rejected["outside_window"] += 1
                    continue
                base_key = (seller, invoice, str(issue.year))
                header = (issue, received, due, paid, amount, currency)
                groups[base_key].append(header)
        accepted = 0
        conflict_groups = 0
        duplicate_line_rows = 0
        for (seller, invoice, _), headers in groups.items():
            unique = set(headers)
            duplicate_line_rows += len(headers) - 1
            if len(unique) != 1:
                conflict_groups += 1
                continue
            issue, received, due, paid, amount, currency = unique.pop()
            output.append(row_record(
                lane="issue_to_payment", country="CZ", source=source,
                buyer=source, seller=f"CZICO:{seller}", invoice=invoice,
                issue=issue, received=received, due=due, paid=paid,
                amount=amount, currency=currency))
            accepted += 1
        evidence[source] = {
            "raw_line_rows": raw_rows,
            "accepted_invoice_rows": accepted,
            "conflicting_invoice_groups": conflict_groups,
            "collapsed_repeated_line_rows": duplicate_line_rows,
            "rejected": dict(rejected),
        }
    return output, evidence


def truth(value: str) -> bool:
    return str(value).strip().lower() == "true"


def load_czech_health(path: Path) -> tuple[list[dict], dict]:
    output = []
    rejected = Counter()
    total = 0
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            total += 1
            if not (truth(row["gate_issue_due_paid"]) and truth(row["reference_usable"])
                    and truth(row["ordinary_named_document_type"])
                    and not truth(row["source_id_has_financial_conflict"])):
                rejected["upstream_gate"] += 1
                continue
            issue, received = parse_date(row["issue_date"]), parse_date(row["received_date"])
            due, paid = parse_date(row["due_date"]), parse_date(row["paid_date"])
            amount = parse_amount(row["amount"])
            if not all((issue, due, paid)) or amount is None or amount <= 0:
                rejected["invalid_required_value"] += 1
                continue
            assert issue and due and paid
            if not valid_window(issue, paid):
                rejected["outside_window"] += 1
                continue
            output.append(row_record(
                lane="issue_to_payment", country="CZ", source="CZ_HEALTH",
                buyer=f"HEALTH:{row['buyer_id']}", seller=f"HEALTH:{row['seller_id']}",
                invoice=row["invoice_reference"], issue=issue, received=received,
                due=due, paid=paid, amount=amount, currency=row["currency"]))
    return output, {"source_rows": total, "accepted_invoice_rows": len(output),
                    "rejected": dict(rejected)}


def eligibility_profiles(rows: list[dict]) -> tuple[dict, dict]:
    train_pairs = Counter()
    for row in rows:
        if row["split"] == "train":
            train_pairs[(row["lane"], row["seller_id"], row["buyer_id"])] += 1
    profiles = {}
    by_seller = defaultdict(list)
    for (lane, seller, _buyer), count in train_pairs.items():
        by_seller[(lane, seller)].append(count)
    for key, counts in by_seller.items():
        profiles[key] = {
            "train_rows": sum(counts),
            "train_buyers": len(counts),
            "train_repeat_buyers_2": sum(value >= 2 for value in counts),
            "train_repeat_buyers_5": sum(value >= 5 for value in counts),
        }
    thresholds = {
        "panel_v01": {"minimum_train_rows": 20, "minimum_train_buyers": 3,
                      "minimum_train_buyers_with_2_rows": 2},
        "threshold_grid": {},
    }
    for buyers in (2, 3, 5, 10):
        for rows_required in (10, 20, 50):
            label = f"buyers>={buyers},train_rows>={rows_required},repeat_buyers_2>=2"
            selected = {key for key, value in profiles.items()
                        if value["train_buyers"] >= buyers
                        and value["train_rows"] >= rows_required
                        and value["train_repeat_buyers_2"] >= 2}
            thresholds["threshold_grid"][label] = {
                "sellers": len(selected),
                "all_period_rows": sum((row["lane"], row["seller_id"]) in selected for row in rows),
            }
    selected = {key for key, value in profiles.items()
                if value["train_buyers"] >= 3 and value["train_rows"] >= 20
                and value["train_repeat_buyers_2"] >= 2}
    for row in rows:
        row["panel_eligible_train"] = str((row["lane"], row["seller_id"]) in selected)
    return profiles, thresholds


def summarize(rows: list[dict]) -> dict:
    counter = Counter()
    panel_counter = Counter()
    buyers, sellers = set(), set()
    panel_buyers, panel_sellers = set(), set()
    dates = []
    for row in rows:
        counter[(row["lane"], row["country"], row["source"], row["split"])] += 1
        buyers.add((row["country"], row["buyer_id"]))
        sellers.add((row["country"], row["seller_id"]))
        if row["panel_eligible_train"] == "True":
            panel_counter[(row["lane"], row["country"], row["source"], row["split"])] += 1
            panel_buyers.add((row["country"], row["buyer_id"]))
            panel_sellers.add((row["country"], row["seller_id"]))
        dates.append(row["anchor_date"])
    nested = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    panel_nested = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
    for (lane, country, source, split), count in sorted(counter.items()):
        nested[lane][country][source][split] = count
    for (lane, country, source, split), count in sorted(panel_counter.items()):
        panel_nested[lane][country][source][split] = count
    return {
        "rows": len(rows),
        "panel_rows": sum(row["panel_eligible_train"] == "True" for row in rows),
        "distinct_buyers": len(buyers),
        "distinct_sellers": len(sellers),
        "panel_distinct_buyers": len(panel_buyers),
        "panel_distinct_sellers": len(panel_sellers),
        "anchor_date_min": min(dates) if dates else None,
        "anchor_date_max": max(dates) if dates else None,
        "by_lane_country_source_split": nested,
        "panel_by_lane_country_source_split": panel_nested,
    }


def write_rows(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true",
                        help="Reuse and verify the immutable MZP snapshot")
    parser.add_argument("--raw", type=Path,
                        default=ROOT / "data/T1/raw/public_b2g_v01/2026-10-22")
    parser.add_argument("--output", type=Path,
                        default=ROOT / "data/T1/interim/public_b2g_v01")
    parser.add_argument("--evidence", type=Path, default=(
        ROOT / "research/references/data-checks/t1/t1_public_b2g_v01.json"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    manifest = build_mzp_snapshot(args.raw / "czech_mzp", args.offline)
    mzp_rows, mzp_evidence = load_mzp(args.raw / "czech_mzp")
    health_rows, health_evidence = load_czech_health(
        ROOT / "data/T1/interim/czech/2026-10-18/health_invoice_audit.csv")
    rows = mzp_rows + health_rows
    profiles, thresholds = eligibility_profiles(rows)
    rows.sort(key=lambda item: (item["lane"], item["country"], item["source"],
                                item["anchor_date"], item["record_id"]))
    issue_rows = [row for row in rows if row["lane"] == "issue_to_payment"]
    write_rows(args.output / "issue_to_payment.csv", issue_rows)
    write_rows(args.output / "issue_to_payment_panel.csv", [
        row for row in issue_rows if row["panel_eligible_train"] == "True"])
    output_names = ("issue_to_payment.csv", "issue_to_payment_panel.csv")
    output_hashes = {name: {"rows": sum(1 for _ in (args.output / name).open(encoding="utf-8")) - 1,
                            "bytes": (args.output / name).stat().st_size,
                            "sha256": digest_file(args.output / name)}
                     for name in output_names}
    anonymized_profiles = Counter()
    for (lane, _seller), profile in profiles.items():
        anonymized_profiles[(lane, profile["train_buyers"], profile["train_rows"])] += 1
    evidence = {
        "dataset": "t1_public_b2g_v01",
        "built_on": RESEARCH_DATE,
        "contract": {
            "window": [WINDOW_START.isoformat(), WINDOW_END.isoformat()],
            "splits": {"train": "2019-01-01..2023-12-31",
                       "validation": "2024-01-01..2024-12-31",
                       "test": "2025-01-01..2025-12-31",
                       "external_2026": "2026-01-01..2026-09-30 (partial-year domain check)"},
            "eligibility_is_computed_from": "train rows only",
            "target": "issue_to_payment_with_due_date",
            "receipt_to_payment_excluded": True,
            "observed_paid_only": True,
            "privacy": "No names, descriptions, addresses, invoice references, or public business IDs in row outputs.",
        },
        "sources": {
            "czech_mzp_family": {"manifest": manifest, "audit": mzp_evidence},
            "czech_health": health_evidence,
        },
        "summary": summarize(rows),
        "panel_selection": thresholds,
        "anonymous_train_profile_histogram": [
            {"lane": key[0], "train_buyers": key[1], "train_rows": key[2], "sellers": count}
            for key, count in sorted(anonymized_profiles.items())],
        "outputs": output_hashes,
        "limitations": [
            "The included Czech publications contain observed paid invoices; open and censored invoices are absent.",
            "Receipt-to-payment sources are research leads only and are not emitted or used for cohort selection.",
            "Czech Health IDs are source-scoped and cannot be joined to MZP supplier IDs.",
            "The seven MZP-family files retain payment dates mainly for 2015-2017; their modern rows are rejected rather than assigned a synthetic payment date.",
            "The 2026 split is a partial-year Czech external check, not a complete-year temporal test.",
            "No model was trained and no predictive-performance claim is made by this build.",
        ],
    }
    write_json(args.output / "dataset_manifest.json", evidence)
    write_json(args.evidence, evidence)
    print(json.dumps({"summary": evidence["summary"], "outputs": output_hashes},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
