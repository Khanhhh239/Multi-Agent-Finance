"""Snapshot and audit adjacent invoice-payment sources for T1.

The script performs bounded source research.  It audits the complete versioned
ACT notifiable-invoice CSV, inspects all current Barnet late-payment workbooks,
and records access/schema evidence for adjacent ERP/research sources.  It also
audits a small public AR candidate and records controlled-access leads with the
correct seller-to-many-buyers direction.  Sources are classified by transaction
direction because public accounts-payable data from one buyer cannot validate
customer behaviour for one seller.  Raw snapshots are inspection-only, stay
outside Git, and are never training input.
"""

import argparse
from collections import Counter
import csv
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import urllib.error
import urllib.request
import zipfile
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parents[2]
RESEARCH_DATE = "2026-10-21"
MAX_BYTES = 12_000_000
THESIS_REVISION = "46f96c4d4a6c4534266abc142fa8ce0b921ea8e4"


def raw_github(repo, revision, path):
    return f"https://raw.githubusercontent.com/{repo}/{revision}/{path}"


REQUESTS = {
    "act/official_page.html": (
        "https://www.procurement.act.gov.au/registers/act-government-notifiable-invoices-register"),
    "act/schema.json": (
        "https://publicdata.au/d/act-notifiable-invoices/v/2026-09-18/schema.json"),
    "act/manifest.json": (
        "https://publicdata.au/d/act-notifiable-invoices/v/2026-09-18/manifest.json"),
    "act/data.csv.gz": (
        "https://publicdata.au/d/act-notifiable-invoices/v/2026-09-18/data.csv.gz"),
    "barnet/landing.html": (
        "https://open.barnet.gov.uk/dataset/financial-invoices-late-payments-2g58n"),
    "barnet/2025-12_to_2026-05.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/dyw/"
        "Late%20Payment%20of%20Finance%20Invoices%20from%2001.12.25%20-31.05.26.xlsx"),
    "barnet/2025-06_to_2025-11.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/w3g/"
        "Late%20Payment%20of%20Finance%20Invoice%2001.06.25%20-%2030.11.25.xlsx"),
    "barnet/2024-04_to_2025-05.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/mty/"
        "Late%20payment%20of%20finance%20invoice%20from%2001.04.24-30.05.25.xlsx"),
    "barnet/2023-24.xlsx": (
        "https://open.barnet.gov.uk/download/2g58n/v11/"
        "Late%20Payment%20of%20Finance%20Invoices%2023-24.xlsx"),
    "barnet/payment_performance.csv": (
        "https://open.barnet.gov.uk/download/2g58n/gwy/"
        "Barnet%20Council%20Payment%20performance%20(2).csv"),
    "cook/data_gov_landing.html": "https://catalog.data.gov/dataset/ccp-invoice-register",
    "cook/columns.json": "https://datacatalog.cookcountyil.gov/api/views/exta-e29u/columns.json",
    "cook/sample.json": "https://datacatalog.cookcountyil.gov/resource/exta-e29u.json?$limit=5",
    "microsoft/business_central.html": (
        "https://learn.microsoft.com/en-us/dynamics365/business-central/"
        "ui-extensions-late-payment-prediction"),
    "microsoft/dynamics_finance.html": (
        "https://learn.microsoft.com/en-us/dynamics365/finance/finance-insights/"
        "enable-cust-paymnt-prediction"),
    "odoo/payments.html": (
        "https://www.odoo.com/documentation/17.0/applications/finance/accounting/payments/multiple.html"),
    "thesis/commit.json": (
        "https://api.github.com/repos/anneryeo/invoice-payment-prediction-thesis/commits/"
        f"{THESIS_REVISION}"),
    "thesis/root_listing.json": (
        "https://api.github.com/repos/anneryeo/invoice-payment-prediction-thesis/contents"
        f"?ref={THESIS_REVISION}"),
    "thesis/README.md": raw_github(
        "anneryeo/invoice-payment-prediction-thesis", THESIS_REVISION, "README.md"),
    "thesis/FEATURE_REFERENCE.md": raw_github(
        "anneryeo/invoice-payment-prediction-thesis", THESIS_REVISION, "FEATURE_REFERENCE.md"),
    "research/stemly.html": (
        "https://link.springer.com/article/10.1007/s44257-024-00013-2"),
    "research/ibm_invoice_to_cash.html": (
        "https://research.ibm.com/publications/"
        "using-predictive-analysis-to-improve-invoice-to-cash-collection"),
    "research/bahrami_pubmed.xml": (
        "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
        "?db=pubmed&id=31976741&retmode=xml"),
    "research/dnb_trade_credit.html": (
        "https://www.dnb.com/en-us/products/global-trade-exchange-program.html"),
    "research/microsoft_predicting_ar.html": (
        "https://www.microsoft.com/en-us/research/publication/"
        "predicting-account-receivables-with-machine-learning/"),
    "research/smart_data_sage_report.pdf": (
        "https://cms.smartdatafoundry.com/wp-content/uploads/2022/11/"
        "221103-late-and-slow-payments-part-one-Final59.pdf"),
    "research/smart_data_tre_eoi.html": (
        "https://forms.smartdatafoundry.com/tre-expression-of-interest"),
    "research/smart_data_dmp_faq.html": (
        "https://support.smartdatafoundry.com/helpcentre/data-management-plan-faqs"),
    "research/smart_data_five_safes.html": (
        "https://smartdatafoundry.com/resources/blog/"
        "responsible-data-sharing-what-is-the-five-safes-framework"),
    "research/tofu_invoice_terms.html": "https://tofu.com/blog/invoice-payment-terms",
    "research/zenodo_smart_data_report.json": "https://zenodo.org/api/records/12782642",
    "research/zenodo_payment_export.json": "https://zenodo.org/api/records/17092322",
    "research/informs_case.html": (
        "https://pubsonline.informs.org/do/10.1287/LYTX.2024.03.06/full/"),
    "public_ar/kaggle_metadata.json": (
        "https://www.kaggle.com/api/v1/datasets/view/"
        "sonalisingh1411/accounts-receivable-and-payment-delay-analysis"),
    "public_ar/dataset.zip": (
        "https://www.kaggle.com/api/v1/datasets/download/"
        "sonalisingh1411/accounts-receivable-and-payment-delay-analysis"),
    "external_features/australia_register.html": (
        "https://register.paymenttimes.gov.au/data.html"),
    "external_features/australia_how_to.html": (
        "https://paymenttimes.gov.au/register/how-to-use-the-register"),
}

EXPECTED_FAILURES = {
    "act/official_page.html": 403,
    "cook/columns.json": 403,
    "cook/sample.json": 403,
    "research/informs_case.html": 403,
    "external_features/australia_how_to.html": 503,
}


def sha256(payload):
    return hashlib.sha256(payload).hexdigest()


def write_json_exclusive(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def read_text_optional(path):
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8-sig", errors="replace").lower()


def metadata_text(value):
    return json.dumps(value, ensure_ascii=False).lower()


def snapshot(folder, offline):
    manifest_path = folder / "source_manifest.json"
    spec_hash = sha256(json.dumps(REQUESTS, sort_keys=True).encode())
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        if manifest.get("spec_hash") != spec_hash:
            raise ValueError("Existing snapshot uses a different request specification")
        by_name = {item["file"]: item for item in manifest["responses"]}
        if set(by_name) != set(REQUESTS):
            raise ValueError("Existing snapshot does not cover all requests")
        for name, item in by_name.items():
            if not (isinstance(item["status"], int) and 200 <= item["status"] < 300):
                item["expected_failure"] = EXPECTED_FAILURES.get(name) == item["status"]
            if isinstance(item["status"], int) and 200 <= item["status"] < 300:
                payload = (folder / name).read_bytes()
                if len(payload) != item["bytes"] or sha256(payload) != item["sha256"]:
                    raise ValueError(f"Cached bytes differ for {name}")
        return manifest
    if offline:
        raise ValueError("Offline mode requires an existing complete snapshot")
    if folder.exists() and any(folder.iterdir()):
        raise ValueError("Snapshot directory is non-empty but has no manifest")
    folder.mkdir(parents=True, exist_ok=True)
    responses = []
    for name, url in REQUESTS.items():
        checked = datetime.now(timezone.utc).isoformat()
        request = urllib.request.Request(
            url, headers={"User-Agent": "FinanceProject-T1-AdjacentResearch/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                payload = response.read(MAX_BYTES + 1)
                if len(payload) > MAX_BYTES:
                    raise ValueError("Response exceeds 12 MB bound")
                target = folder / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(payload)
                responses.append({"file": name, "url": url, "status": response.status,
                    "checked_at_utc": checked, "bytes": len(payload), "sha256": sha256(payload)})
        except urllib.error.HTTPError as exc:
            responses.append({"file": name, "url": url, "status": exc.code,
                "checked_at_utc": checked,
                "expected_failure": EXPECTED_FAILURES.get(name) == exc.code})
        except (OSError, ValueError) as exc:
            responses.append({"file": name, "url": url, "status": None,
                "checked_at_utc": checked, "error_type": type(exc).__name__,
                "reason": str(exc)[:240]})
    manifest = {"spec_hash": spec_hash, "use_policy": "inspection_only_not_training_data",
        "responses": responses}
    write_json_exclusive(manifest_path, manifest)
    return manifest


def parse_iso_date(value):
    value = (value or "").strip()
    if not value:
        return None
    try:
        return datetime.fromisoformat(value[:10]).date()
    except ValueError:
        return None


def percentile(values, fraction):
    if not values:
        return None
    ordered = sorted(values)
    return ordered[round((len(ordered) - 1) * fraction)]


def audit_act(path):
    with gzip.open(path, "rt", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames or []
        rows = list(reader)
    required = {"supplier_name", "supplier_abn", "reporting_entity", "publish_description",
        "date_invoice_received", "payment_date", "payment_amount", "contract_number"}
    if set(fields) != required:
        raise ValueError(f"Unexpected ACT fields: {fields}")
    counters = Counter()
    suppliers, entities, exact_rows, days, years = set(), set(), set(), [], Counter()
    for row in rows:
        key = tuple(row[field] for field in fields)
        counters["exact_duplicate_rows"] += key in exact_rows
        exact_rows.add(key)
        suppliers.add(row["supplier_abn"] or row["supplier_name"])
        entities.add(row["reporting_entity"])
        received = parse_iso_date(row["date_invoice_received"])
        paid = parse_iso_date(row["payment_date"])
        counters["missing_received_date"] += not row["date_invoice_received"].strip()
        counters["invalid_received_date"] += bool(row["date_invoice_received"].strip()) and received is None
        counters["missing_payment_date"] += not row["payment_date"].strip()
        counters["invalid_payment_date"] += bool(row["payment_date"].strip()) and paid is None
        if received and paid:
            delta = (paid - received).days
            days.append(delta)
            counters["payment_before_received"] += delta < 0
            counters["same_day_payment"] += delta == 0
            counters["paid_within_30_calendar_days"] += 0 <= delta <= 30
        if received:
            years[str(received.year)] += 1
        try:
            amount = Decimal(row["payment_amount"])
            counters["nonpositive_payment_amount"] += amount <= 0
            counters["below_25000_payment_amount"] += 0 < amount < 25000
        except InvalidOperation:
            counters["invalid_payment_amount"] += 1
    return {
        "version": "2026-09-18", "rows": len(rows), "fields": fields,
        "distinct_supplier_keys": len(suppliers), "distinct_reporting_entities": len(entities),
        "counts": dict(counters), "received_year_counts": dict(sorted(years.items())),
        "received_to_payment_days": {"observations": len(days), "minimum": min(days) if days else None,
            "median": percentile(days, 0.5), "p95": percentile(days, 0.95),
            "maximum": max(days) if days else None},
        "grain_warning": "No published invoice ID; duplicate business events cannot be resolved from exact rows alone.",
        "selection": "Only paid invoices at or above the statutory publication threshold are in scope.",
        "t1_use": (
            "Technical receipt-to-payment/date benchmark only. The register observes public buyers paying "
            "many suppliers, so it cannot validate repeat-customer behaviour for a seller's AR portfolio."),
    }


def parse_us_date(value):
    value = (value or "").strip()
    if not value:
        return None
    try:
        return datetime.strptime(value, "%m/%d/%Y").date()
    except ValueError:
        return None


def audit_public_ar_candidate(path):
    """Audit rows without treating the Kaggle publisher's claim as provenance."""
    with zipfile.ZipFile(path) as archive:
        members = {item.filename: item for item in archive.infolist()}
        if "Dataset.csv" not in members:
            raise ValueError(f"Expected Dataset.csv, found {sorted(members)}")
        csv_hash = hashlib.sha256()
        buyer_counts, buyer_names, name_buyers = Counter(), {}, {}
        document_ids, clearing_docs = set(), Counter()
        delay_flags, methods = Counter(), Counter()
        issue_dates, clearing_dates = [], []
        missing_clearing = 0
        lifetime_count_matches = 0
        rows = 0
        with archive.open("Dataset.csv") as binary:
            payload = binary.read()
        csv_hash.update(payload)
        reader = csv.reader(io.StringIO(payload.decode("utf-8-sig")))
        original_fields = next(reader)
        seen, fields = Counter(), []
        for field in original_fields:
            seen[field] += 1
            fields.append(field if seen[field] == 1 else f"{field}__{seen[field]}")
        indexes = {field: position for position, field in enumerate(fields)}
        for values in reader:
            if len(values) != len(fields):
                raise ValueError(f"Unexpected column count at data row {rows + 2}")
            rows += 1
            buyer = values[indexes["Cust_Num"]]
            name = values[indexes["Customer_Name"]]
            buyer_counts[buyer] += 1
            buyer_names.setdefault(buyer, set()).add(name)
            name_buyers.setdefault(name, set()).add(buyer)
            document_ids.add(values[indexes["Document_No"]])
            clearing = values[indexes["Clearing_doc"]]
            if clearing:
                clearing_docs[clearing] += 1
            missing_clearing += not values[indexes["Clearing_date"]].strip()
            delay_flags[values[indexes["DelayFlag"]]] += 1
            methods[values[indexes["Payment_Method_description"]]] += 1
            issue = parse_us_date(values[indexes["Doc_Date"]])
            cleared = parse_us_date(values[indexes["Clearing_date"]])
            if issue:
                issue_dates.append(issue)
            if cleared:
                clearing_dates.append(cleared)
            try:
                stated_orders = int(values[indexes["No_of_orders_by_customer"]])
            except ValueError:
                stated_orders = None
            # Final equality is checked after the full-history counts are known.
            if stated_orders is not None:
                lifetime_count_matches += 1
        with archive.open("Dataset.csv") as binary:
            check_reader = csv.reader(io.TextIOWrapper(binary, encoding="utf-8-sig", newline=""))
            check_fields = next(check_reader)
            order_index = check_fields.index("No_of_orders_by_customer")
            buyer_index = check_fields.index("Cust_Num")
            lifetime_count_matches = sum(
                int(values[order_index]) == buyer_counts[values[buyer_index]]
                for values in check_reader)
    repeats = sorted(buyer_counts.values())
    return {
        "archive_bytes": path.stat().st_size,
        "archive_sha256": sha256(path.read_bytes()),
        "csv_bytes_uncompressed": members["Dataset.csv"].file_size,
        "csv_sha256": csv_hash.hexdigest(),
        "rows": rows,
        "columns": len(fields),
        "fields": fields,
        "duplicate_source_header": "Weekday_due",
        "distinct_customer_ids": len(buyer_counts),
        "distinct_customer_names": len(name_buyers),
        "distinct_document_numbers": len(document_ids),
        "customer_repeat_profile": {
            "customers_with_more_than_one_invoice": sum(value > 1 for value in repeats),
            "customers_with_at_least_10_invoices": sum(value >= 10 for value in repeats),
            "customers_with_at_least_100_invoices": sum(value >= 100 for value in repeats),
            "median_invoices_per_customer": percentile(repeats, 0.5),
            "maximum_invoices_per_customer": max(repeats)},
        "clearing_documents": {
            "distinct": len(clearing_docs),
            "linked_to_multiple_invoices": sum(value > 1 for value in clearing_docs.values()),
            "maximum_invoices_on_one_clearing_document": max(clearing_docs.values())},
        "delay_flag_counts": dict(delay_flags),
        "payment_method_counts": dict(methods.most_common()),
        "missing_clearing_date": missing_clearing,
        "open_invoice_rows": missing_clearing,
        "issue_date_range": [str(min(issue_dates)), str(max(issue_dates))],
        "clearing_date_range": [str(min(clearing_dates)), str(max(clearing_dates))],
        "customer_ids_linked_to_multiple_names": sum(
            len(values) > 1 for values in buyer_names.values()),
        "customer_names_linked_to_multiple_ids": sum(
            len(values) > 1 for values in name_buyers.values()),
        "rows_where_published_order_count_equals_full_history_customer_count": lifetime_count_matches,
        "future_information_warning": (
            "No_of_orders_by_customer equals the final full-history group size on every row and cannot "
            "be used at an earlier prediction cutoff."),
        "orientation": "one_implicit_seller_to_many_repeat_buyers",
        "seller_id_present": False,
        "provenance_status": "unverified_publisher_claim_only",
        "training_decision": (
            "Do not treat as verified-real T1 data until the originating organisation, collection path "
            "and publisher authority to distribute the rows are documented; paid-only rows also cannot "
            "represent an open receivables portfolio."),
    }


def column_number(reference):
    letters = re.match(r"[A-Z]+", reference or "")
    value = 0
    for char in letters.group(0) if letters else "":
        value = value * 26 + ord(char) - 64
    return value - 1


def normalize_header(value):
    text = re.sub(r"[^a-z0-9]+", "_", str(value).strip().lower()).strip("_")
    return text


def xlsx_sheets(path):
    main_ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    rel_ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    pkg_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    with zipfile.ZipFile(path) as archive:
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            for item in root.findall(f"{{{main_ns}}}si"):
                shared.append("".join(node.text or "" for node in item.iter(f"{{{main_ns}}}t")))
        workbook = ET.fromstring(archive.read("xl/workbook.xml"))
        relations = ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
        targets = {rel.attrib["Id"]: rel.attrib["Target"]
                   for rel in relations.findall(f"{{{pkg_ns}}}Relationship")}
        result = []
        for sheet in workbook.find(f"{{{main_ns}}}sheets"):
            name = sheet.attrib["name"]
            target = targets[sheet.attrib[f"{{{rel_ns}}}id"]].lstrip("/")
            member = target if target.startswith("xl/") else f"xl/{target}"
            xml = ET.fromstring(archive.read(member))
            rows = []
            for row in xml.iter(f"{{{main_ns}}}row"):
                values = {}
                for cell in row.findall(f"{{{main_ns}}}c"):
                    position = column_number(cell.attrib.get("r"))
                    cell_type = cell.attrib.get("t")
                    value_node = cell.find(f"{{{main_ns}}}v")
                    inline = cell.find(f"{{{main_ns}}}is")
                    value = ""
                    if inline is not None:
                        value = "".join(node.text or "" for node in inline.iter(f"{{{main_ns}}}t"))
                    elif value_node is not None:
                        value = value_node.text or ""
                        if cell_type == "s" and value:
                            value = shared[int(value)]
                    values[position] = value
                if values:
                    width = max(values) + 1
                    rows.append([values.get(index, "") for index in range(width)])
            result.append((name, rows))
        return result


def find_header(rows):
    best = None
    keywords = ("supplier", "invoice", "payment", "cleared", "gross", "date", "reference")
    for index, row in enumerate(rows[:30]):
        normalized = [normalize_header(value) for value in row]
        score = sum(any(keyword in value for keyword in keywords) for value in normalized if value)
        if best is None or score > best[0]:
            best = (score, index, normalized)
    if not best or best[0] < 3:
        return None
    headers = []
    seen = Counter()
    for index, value in enumerate(best[2]):
        key = value or f"column_{index + 1}"
        seen[key] += 1
        headers.append(key if seen[key] == 1 else f"{key}_{seen[key]}")
    return best[1], headers


def excel_date(value):
    text = str(value).strip()
    if not text:
        return None
    try:
        number = float(text)
        if 20000 <= number <= 80000:
            return (datetime(1899, 12, 30) + timedelta(days=number)).date()
    except ValueError:
        pass
    for pattern in ("%Y-%m-%d", "%d/%m/%Y", "%d.%m.%Y", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    return None


def audit_barnet_workbook(path):
    reports = []
    for sheet_name, rows in xlsx_sheets(path):
        found = find_header(rows)
        if not found:
            reports.append({"sheet": sheet_name, "status": "header_not_found", "nonempty_rows": len(rows)})
            continue
        header_index, headers = found
        body = []
        for values in rows[header_index + 1:]:
            padded = values + [""] * (len(headers) - len(values))
            if any(str(value).strip() for value in padded[:len(headers)]):
                body.append(dict(zip(headers, padded[:len(headers)])))
        invoice_date_keys = [key for key in headers if "invoice" in key and "date" in key]
        payment_date_keys = [key for key in headers if "payment" in key and "date" in key]
        cleared_date_keys = [key for key in headers if "cleared" in key and "date" in key]
        due_keys = [key for key in headers if any(term in key for term in ("due_date", "should_have_been_paid"))]
        target_keys = payment_date_keys or cleared_date_keys
        counts = Counter()
        deltas = []
        for row in body:
            start = excel_date(row[invoice_date_keys[0]]) if invoice_date_keys else None
            target = excel_date(row[target_keys[0]]) if target_keys else None
            due = excel_date(row[due_keys[0]]) if due_keys else None
            counts["missing_invoice_date"] += bool(invoice_date_keys) and start is None
            counts["missing_payment_or_cleared_date"] += bool(target_keys) and target is None
            counts["payment_before_invoice"] += bool(start and target and target < start)
            counts["payment_on_or_before_due"] += bool(due and target and target <= due)
            if start and target:
                deltas.append((target - start).days)
        reports.append({"sheet": sheet_name, "status": "inspected", "header_row_1_based": header_index + 1,
            "headers": headers, "data_rows": len(body), "date_columns": {
                "invoice": invoice_date_keys, "payment": payment_date_keys,
                "cleared": cleared_date_keys, "due": due_keys},
            "counts": dict(counts), "invoice_to_payment_days": {
                "observations": len(deltas), "minimum": min(deltas) if deltas else None,
                "median": percentile(deltas, 0.5), "p95": percentile(deltas, 0.95),
                "maximum": max(deltas) if deltas else None}})
    return reports


def inspect_text_sources(folder):
    bc = (folder / "microsoft/business_central.html").read_text(encoding="utf-8-sig").lower()
    dynamics = (folder / "microsoft/dynamics_finance.html").read_text(encoding="utf-8-sig").lower()
    odoo = (folder / "odoo/payments.html").read_text(encoding="utf-8-sig").lower()
    thesis = (folder / "thesis/README.md").read_text(encoding="utf-8-sig")
    listing = read_json(folder / "thesis/root_listing.json")
    commit = read_json(folder / "thesis/commit.json")
    stemly = (folder / "research/stemly.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    ibm = (folder / "research/ibm_invoice_to_cash.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    bahrami = (folder / "research/bahrami_pubmed.xml").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    dnb = (folder / "research/dnb_trade_credit.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    microsoft_ar = (folder / "research/microsoft_predicting_ar.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    smart_eoi = (folder / "research/smart_data_tre_eoi.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    smart_dmp = (folder / "research/smart_data_dmp_faq.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    smart_five_safes = (folder / "research/smart_data_five_safes.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    tofu = (folder / "research/tofu_invoice_terms.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    informs = read_text_optional(folder / "research/informs_case.html")
    smart_zenodo = read_json(folder / "research/zenodo_smart_data_report.json")
    payment_export = read_json(folder / "research/zenodo_payment_export.json")
    kaggle_ar = read_json(folder / "public_ar/kaggle_metadata.json")
    australia_terms = (folder / "external_features/australia_register.html").read_text(
        encoding="utf-8-sig", errors="replace").lower()
    australia_how_to = read_text_optional(folder / "external_features/australia_how_to.html")
    return {
        "business_central": {
            "url": REQUESTS["microsoft/business_central.html"],
            "mentions_sme_standard_model": "small to medium-sized businesses" in bc,
            "documents_training_fields": "data required to train and evaluate" in bc,
            "public_row_level_training_corpus_found": False,
            "assessment": "Useful feature contract and pretrained-product evidence, not a downloadable corpus."},
        "dynamics_finance": {
            "url": REQUESTS["microsoft/dynamics_finance.html"],
            "requires_settled_history": "settled customer transactions" in dynamics,
            "predicts_open_invoices": "for each open invoice" in dynamics,
            "public_row_level_training_corpus_found": False,
            "assessment": "Confirms partner-history requirements; no public transaction corpus on the inspected page."},
        "odoo": {
            "url": REQUESTS["odoo/payments.html"],
            "documents_multiple_payments": "multiple payments on the same invoice" in odoo,
            "documents_partial_payment": "partial payment" in odoo,
            "documents_bank_reconciliation": "bank transaction" in odoo,
            "public_row_level_training_corpus_found": False,
            "assessment": "Adjacent ERP semantics support an allocation/reconciliation export, not a dataset."},
        "private_education_thesis": {
            "repository": "https://github.com/anneryeo/invoice-payment-prediction-thesis",
            "revision": commit["sha"],
            "revision_date": commit["commit"]["committer"]["date"],
            "source_database_private": "source database is private" in thesis.lower(),
            "source_database_not_in_repository": "not included in this repository" in thesis.lower(),
            "license_file_at_root": any(item["name"].lower().startswith("license") for item in listing),
            "assessment": "Real-use-case code/schema evidence; source student receivables are private and unavailable."},
        "stemly_saini_2024": {
            "url": REQUESTS["research/stemly.html"],
            "landing_snapshot_contains_article": "data i includes 9932 invoices" in stemly,
            "supporting_pdf": {
                "path": "research/references/papers/invoice_forecasting_discrete_survival.pdf",
                "sha256": sha256((ROOT / "research/references/papers/"
                    "invoice_forecasting_discrete_survival.pdf").read_bytes())},
            "orientation": "few_sellers_many_buyers",
            "data_i": {"invoices": 9932, "customers": 401, "period": "2018-02 to 2020-07"},
            "data_ii": {"invoices": 35192, "customers": 1351, "period": "2009-01 to 2017-09"},
            "required_fields_described": [
                "customer_id", "amount", "issue_date", "payment_terms", "due_date", "closed_date"],
            "all_application_invoices_paid": True,
            "data_access": "available from the authors only with Stemly permission",
            "fact_basis": "primary article reviewed in the hash-pinned local PDF; landing snapshot was bot-challenged",
            "public_row_level_corpus_found": False,
            "assessment": (
                "Best verified structural match: recurring customers observed from the seller AR side, "
                "but access requires Stemly permission and the applications contain no censoring.")},
        "ibm_zeng_2008": {
            "url": REQUESTS["research/ibm_invoice_to_cash.html"],
            "orientation": "few_sellers_many_buyers",
            "real_world_multiple_firms": "real-world transaction data from multiple firms" in ibm,
            "public_row_level_corpus_found": False,
            "assessment": (
                "Strong real AR precedent for predicting newly created invoices; the inspected official "
                "publication page does not provide the transaction rows.")},
        "bahrami_2020": {
            "url": REQUESTS["research/bahrami_pubmed.xml"],
            "orientation": "invoice_issuer_many_customers",
            "customer_count_claim": "more than 1.6 million customers",
            "claim_present_in_page": "more than 1.6 million customers" in bahrami,
            "history_and_collection_actions": all(term in bahrami for term in (
                "invoice and payment history", "e-mail", "phone call")),
            "public_row_level_corpus_found": False,
            "assessment": (
                "Highly relevant customer-panel precedent; no reusable microdata link was found on the "
                "inspected PubMed record.")},
        "dnb_global_trade_exchange": {
            "url": REQUESTS["research/dnb_trade_credit.html"],
            "orientation": "many_suppliers_many_buyers_aggregated_to_buyer",
            "participant_ar_sharing_described": all(term in dnb for term in (
                "global trade exchange program", "accounts receivable", "how your customers pay you")),
            "export_to_customer_database_described": "customer databases" in dnb,
            "relationship_rows_public": False,
            "assessment": (
                "Commercial/permissioned lead for external buyer payment signals; the research data are "
                "aggregated and do not expose a seller-specific invoice panel for T1.")},
        "microsoft_predicting_ar": {
            "url": REQUESTS["research/microsoft_predicting_ar.html"],
            "orientation": "seller_accounts_receivable",
            "page_mentions_multinational_bank": "multinational bank" in microsoft_ar,
            "public_row_level_corpus_found": False,
            "assessment": "Relevant industrial case study, not an openly distributed invoice corpus."},
        "smart_data_foundry_sage": {
            "report_url": REQUESTS["research/smart_data_sage_report.pdf"],
            "report_sha256": sha256((folder / "research/smart_data_sage_report.pdf").read_bytes()),
            "zenodo_record_url": smart_zenodo.get("links", {}).get("html"),
            "zenodo_doi": smart_zenodo.get("metadata", {}).get("doi"),
            "orientation": "many_sellers_each_with_repeat_buyers",
            "seller_accounts": "approximately 110000 Sage Accounting customers",
            "invoices": "approximately 58 million sales invoices",
            "period": "2010 to 2022",
            "invoice_fields_reported": [
                "issue_date", "due_date", "amount", "actual_payment_date_or_dates"],
            "buyer_identity_scope": (
                "Repeat client identity can be linked within a Sage seller, not across different sellers."),
            "fact_basis": "Primary Smart Data Foundry/Sage report reviewed; report bytes are hash-pinned.",
            "public_row_level_corpus_found": False,
            "tre_expression_of_interest": REQUESTS["research/smart_data_tre_eoi.html"],
            "eoi_page_mentions_research_question": "research question" in smart_eoi,
            "eoi_page_mentions_ethics": "ethics" in smart_eoi,
            "tre_secure_environment_described": all(term in smart_dmp for term in (
                "virtual machine", "jupyter")),
            "five_safes_described": "five safes" in smart_five_safes,
            "exact_dataset_current_catalogue_status": "not_confirmed",
            "assessment": (
                "Strongest verified real-data access lead found: correct direction and target dates, but "
                "only aggregate results are public. Submit an EOI and confirm this exact microdataset is "
                "currently available in the TRE before planning a benchmark.")},
        "tofu_field_service": {
            "url": REQUESTS["research/tofu_invoice_terms.html"],
            "orientation": "many_field_service_sellers_to_their_clients",
            "invoices_claimed": 3750978,
            "businesses_claimed": 442894,
            "period": "2025-01-01 to 2026-05-31",
            "paid_invoices_claimed": 1742870,
            "paid_invoices_with_reliable_date_claimed": 1286649,
            "multiple_installment_invoices_claimed": 38553,
            "claims_detected_in_snapshot": {
                "invoice_count": "3,750,978" in tofu,
                "business_count": "442,894" in tofu,
                "installment_count": "38,553" in tofu},
            "public_row_level_corpus_found": False,
            "domain_warning": "US field services likely mix business and consumer buyers.",
            "target_semantics_warning": (
                "The article reports that manually marked payment dates can lag cash receipt and same-day "
                "dates were excluded because they are often interface defaults."),
            "assessment": "Verified corpus existence and a partnership lead, not a downloadable dataset."},
        "informs_industrial_case": {
            "url": REQUESTS["research/informs_case.html"],
            "invoices_claimed": 3500000,
            "period": "2020-01 to 2022-12",
            "claim_detected_in_snapshot": "3.5 million" in informs,
            "public_row_level_corpus_found": False,
            "assessment": "Relevant private industrial case and author-contact lead; no data release found."},
        "zenodo_payment_system_export": {
            "url": payment_export.get("links", {}).get("html"),
            "doi": payment_export.get("metadata", {}).get("doi"),
            "title": payment_export.get("metadata", {}).get("title"),
            "license": payment_export.get("metadata", {}).get("license"),
            "assessment": (
                "Not suitable for T1: transaction export lacks an invoice master with issue/due dates; "
                "the record describes phone-number and note fields and has no clear reuse license. Raw "
                "rows were deliberately not downloaded."),
        },
        "kaggle_public_ar_candidate": {
            "url": kaggle_ar.get("urlNullable") or kaggle_ar.get("url"),
            "title": kaggle_ar.get("title"),
            "license_name": kaggle_ar.get("licenseName"),
            "owner_name": kaggle_ar.get("ownerName"),
            "description_mentions_source_organisation": any(term in metadata_text(kaggle_ar) for term in (
                "source company", "source organisation", "source organization")),
            "assessment": (
                "Public and structurally useful, but metadata does not establish the originating company, "
                "collection chain or the uploader's authority to license the business rows.")},
        "australia_payment_times_register": {
            "data_page": REQUESTS["external_features/australia_register.html"],
            "how_to_page": REQUESTS["external_features/australia_how_to.html"],
            "reports_since_june_2021": "june 2021" in australia_how_to,
            "free_dataset_described": "free" in australia_how_to and "data" in australia_how_to,
            "automated_collection_prohibited": all(term in australia_terms for term in (
                "scripts", "data scraping", "data mining")),
            "assessment": (
                "Manual-download aggregate buyer payment-practice feature only. Do not automate collection "
                "under the inspected site terms, and do not use it as invoice-level T1 labels.")},
    }


def orientation_assessment():
    return {
        "target": "one_or_few_sellers_to_many_repeat_buyers",
        "acceptance_gate": [
            "seller scope or seller_id is known",
            "stable buyer_id with enough repeat invoices to estimate customer behaviour",
            "invoice_id, issue date and target-compatible payment or allocation events",
            "open items and a documented observation end for censoring",
            "due date or an explicit design that does not require due-date lateness",
            "provenance, consent/license and lawful reuse are documented",
        ],
        "classifications": [
            {"source": "partner ERP AR export", "orientation": "few_sellers_many_buyers",
             "customer_behaviour_fit": "target", "access": "permissioned_not_yet_obtained"},
            {"source": "Smart Data Foundry/Sage Accounting", "orientation": "many_sellers_repeat_buyers",
             "customer_behaviour_fit": "very_high", "access": "controlled_tre_eoi_required"},
            {"source": "Kaggle public AR candidate (45839 rows)",
             "orientation": "one_implicit_seller_many_repeat_buyers",
             "customer_behaviour_fit": "structurally_high_but_paid_only",
             "access": "public_provenance_unverified"},
            {"source": "Tofu field-service invoices", "orientation": "many_sellers_many_clients",
             "customer_behaviour_fit": "medium_domain_and_identity_unknown", "access": "private_aggregate_only"},
            {"source": "Stemly Data I/II", "orientation": "few_sellers_many_buyers",
             "customer_behaviour_fit": "high", "access": "restricted_paid_only"},
            {"source": "IBM Zeng et al. 2008", "orientation": "few_sellers_many_buyers",
             "customer_behaviour_fit": "high", "access": "private_research_data"},
            {"source": "Bahrami et al. 2020", "orientation": "invoice_issuer_many_customers",
             "customer_behaviour_fit": "high", "access": "private_research_data"},
            {"source": "D&B Global Trade Exchange", "orientation": "many_to_many_buyer_aggregate",
             "customer_behaviour_fit": "medium_external_signal", "access": "commercial_restricted"},
            {"source": "ACT/Czech/DC/Cook County/Barnet", "orientation": "few_public_buyers_many_suppliers",
             "customer_behaviour_fit": "low_wrong_direction", "access": "mostly_public"},
            {"source": "ERPNext/Odoo/Microsoft product documentation", "orientation": "schema_only",
             "customer_behaviour_fit": "none_without_tenant_export", "access": "public_docs_no_rows"},
        ],
        "interpretation": (
            "A large accounts-payable register can test parsing, dates and paid-event mechanics, but it "
            "cannot validate buyer heterogeneity or transfer to a seller's receivables portfolio."),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path,
        default=ROOT / f"data/T1/raw/adjacent_source_research/{RESEARCH_DATE}-v4")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Output exists; choose a new --output")
    manifest = snapshot(args.input, args.offline)
    unexpected = [item for item in manifest["responses"]
                  if not (isinstance(item["status"], int) and 200 <= item["status"] < 300)
                  and EXPECTED_FAILURES.get(item["file"]) != item["status"]]
    if unexpected:
        raise RuntimeError(f"Unexpected source access failures: {unexpected}")
    barnet = {}
    for path in sorted((args.input / "barnet").glob("*.xlsx")):
        barnet[path.name] = audit_barnet_workbook(path)
    report = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "client_research_date": RESEARCH_DATE,
        "script_sha256": sha256(Path(__file__).read_bytes()),
        "scope": (
            "Complete ACT versioned CSV and current Barnet XLSX static audit; metadata/schema "
            "inspection for public AP sources, ERP products and seller-side AR research; row-level "
            "audit of a public AR candidate without assuming its provenance claim is verified."),
        "manifest": manifest,
        "act_notifiable_invoices": {
            "publisher": "Procurement ACT, Chief Minister, Treasury and Economic Development Directorate",
            "official_url": "https://www.data.act.gov.au/d/kzmf-7uhp",
            "license": "CC BY 4.0 as recorded by the versioned distributor from the official portal",
            "audit": audit_act(args.input / "act/data.csv.gz")},
        "barnet_late_payments": {
            "publisher": "London Borough of Barnet", "license": "Open Government Licence v3",
            "landing_page": REQUESTS["barnet/landing.html"], "workbooks": barnet,
            "selection": "Late/over-30-day invoices only; unsuitable for estimating an overall late rate.",
            "orientation": "one_public_buyer_many_suppliers",
            "t1_use": "Technical schema/date inspection only; wrong direction for customer-behaviour T1."},
        "cook_county": {
            "landing_page": REQUESTS["cook/data_gov_landing.html"],
            "dataset_id": "exta-e29u", "catalog_claimed_rows": 2425286,
            "catalog_scope": "Cumulative invoice and payment details from 2016-12-01 onward.",
            "direct_schema_status": 403, "direct_sample_status": 403,
            "license_verified": False,
            "assessment": (
                "Wrong transaction direction for customer-behaviour T1 and direct schema/sample plus reuse "
                "terms were not verified; at most a public-buyer payment-process lead.")},
        "adjacent_systems_and_research": inspect_text_sources(args.input),
        "public_ar_candidate_audit": audit_public_ar_candidate(
            args.input / "public_ar/dataset.zip"),
        "orientation_gate": orientation_assessment(),
        "conclusion": {
            "new_verified_real_public_source": "ACT Notifiable Invoices Register (public-AP direction only)",
            "new_source_sufficient_for_full_t1": False,
            "strongest_real_data_access_lead": (
                "Smart Data Foundry/Sage Accounting: approximately 58 million invoices for about 110000 "
                "seller accounts, with issue, due and actual payment date(s); access must be confirmed and "
                "approved through the TRE rather than downloaded publicly."),
            "best_public_correct_direction_candidate": (
                "The 45839-row Kaggle AR file has repeat customers and due/clearing dates, but every row is "
                "cleared and its originating organisation plus distribution authority remain unverified."),
            "recommended_public_benchmark_use": (
                "Use ACT/Barnet/Czech/DC/Cook County only for bounded technical checks of parsing, "
                "calendar and paid-event mechanics; do not present them as validation of customer behaviour."),
            "recommended_product_validation": (
                "Obtain a consented few-seller/many-buyer ERP export with stable repeat buyer IDs, invoice IDs, "
                "due dates, allocations, open items, revisions and observation coverage; link ERP settlement "
                "to bank value date when cash-in is the target."),
            "best_known_research_match": (
                "Smart Data Foundry/Sage is the strongest controlled-access lead. Stemly Data I/II remain a "
                "smaller correct-direction lead but are restricted and paid-only."),
        },
        "limits": [
            "ACT contains published business identifiers in raw data; only aggregate audit results are committed.",
            "ACT is thresholded and paid-only, lacks invoice ID and contractual due date, and is B2G Australia.",
            "Barnet is outcome-selected late-payment data and therefore cannot identify the base late-payment rate.",
            "Cook County remained HTTP 403 for direct schema and rows; catalog size is not a completed audit.",
            "Microsoft, Odoo and thesis pages provide schema/method evidence, not reusable transaction corpora.",
            "The seller-side research datasets identified are restricted/private; their papers are not data licenses.",
            "Current catalogue availability of the exact Sage invoice microdataset was not confirmed.",
            "The Kaggle AR candidate is public but not provenance-verified, contains no open items and exposes "
            "a full-history customer order count that would leak future information at earlier cutoffs.",
            "The Australian register was not downloaded automatically because the inspected terms prohibit "
            "scripts, scraping and data-mining tools on the service.",
            "No model training, external code execution or cross-source pooling was performed.",
        ],
    }
    write_json_exclusive(args.output, report)


if __name__ == "__main__":
    main()
