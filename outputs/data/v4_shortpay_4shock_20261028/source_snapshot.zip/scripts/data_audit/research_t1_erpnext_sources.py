"""Snapshot and inspect public ERPNext-related sources for T1 data discovery.

This is bounded source research, not a business-data audit or model run.  It
downloads public metadata, pinned ERPNext schemas/demo fixtures and a published
invoice-data schema.  Snapshots are inspection-only and remain outside Git.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys
import urllib.error
import urllib.request


ROOT = Path(__file__).resolve().parents[2]
RESEARCH_DATE = "2026-10-21"
MAX_BYTES = 12_000_000
ERP_REVISION = "05a43eb40fee1da5599004869e6d76c1ad6e8442"
ERP_PRE_REMOVAL_REVISION = "9527ffc41e79454091f98c2d9fd0932ad6a2b025"
ERP_DEMO_REMOVAL_COMMIT = "a34dfaa2753b9bc748e2d629228f1f514f4afa48"
ATOMIC_REVISION = "68ec54a6bfa45ade3b7045d9359cce78af33f8a3"


def raw_github(repo, revision, path):
    return f"https://raw.githubusercontent.com/{repo}/{revision}/{path}"


REQUESTS = {
    "erpnext/current_commit.json": f"https://api.github.com/repos/frappe/erpnext/commits/{ERP_REVISION}",
    "erpnext/demo_listing.json": (
        "https://api.github.com/repos/frappe/erpnext/contents/erpnext/setup/demo_data"
        f"?ref={ERP_REVISION}"
    ),
    "erpnext/license.txt": raw_github("frappe/erpnext", ERP_REVISION, "license.txt"),
    "erpnext/sales_invoice.json": raw_github(
        "frappe/erpnext", ERP_REVISION,
        "erpnext/accounts/doctype/sales_invoice/sales_invoice.json"),
    "erpnext/payment_entry.json": raw_github(
        "frappe/erpnext", ERP_REVISION,
        "erpnext/accounts/doctype/payment_entry/payment_entry.json"),
    "erpnext/payment_entry_reference.json": raw_github(
        "frappe/erpnext", ERP_REVISION,
        "erpnext/accounts/doctype/payment_entry_reference/payment_entry_reference.json"),
    "erpnext/payment_ledger_entry.json": raw_github(
        "frappe/erpnext", ERP_REVISION,
        "erpnext/accounts/doctype/payment_ledger_entry/payment_ledger_entry.json"),
    "erpnext/demo_removal_commit.json": (
        f"https://api.github.com/repos/frappe/erpnext/commits/{ERP_DEMO_REMOVAL_COMMIT}"),
    "erpnext/historical_demo.py": raw_github(
        "frappe/erpnext", ERP_PRE_REMOVAL_REVISION, "erpnext/setup/demo.py"),
    "erpnext/historical_sales_order.json": raw_github(
        "frappe/erpnext", ERP_PRE_REMOVAL_REVISION,
        "erpnext/setup/demo_data/sales_order.json"),
    "erpnext/historical_payment_entry.json": raw_github(
        "frappe/erpnext", ERP_PRE_REMOVAL_REVISION,
        "erpnext/setup/demo_data/payment_entry.json"),
    "erpnext/historical_journal_entry.json": raw_github(
        "frappe/erpnext", ERP_PRE_REMOVAL_REVISION,
        "erpnext/setup/demo_data/journal_entry.json"),
    "erpnext/current_demo_payment_entry.json": raw_github(
        "frappe/erpnext", ERP_REVISION, "erpnext/setup/demo_data/payment_entry.json"),
    "kaggle/search_erpnext.json": "https://www.kaggle.com/api/v1/datasets/list?search=erpnext",
    "kaggle/erpnext_sft.json": (
        "https://www.kaggle.com/api/v1/datasets/view/"
        "rishikhandelwal2025/bilingual-erpnext-sft-dataset"),
    "kaggle/global_b2b_synthetic.json": (
        "https://www.kaggle.com/api/v1/datasets/view/"
        "tharishreddy22/global-b2b-invoice-and-payments-dataset"),
    "kaggle/ibm_late_payment.json": (
        "https://www.kaggle.com/api/v1/datasets/view/"
        "hhenry/finance-factoring-ibm-late-payment-histories"),
    "kaggle/highradius_1.json": (
        "https://www.kaggle.com/api/v1/datasets/view/"
        "pradumn203/payment-date-prediction-for-invoices-dataset"),
    "kaggle/highradius_2.json": (
        "https://www.kaggle.com/api/v1/datasets/view/"
        "rajattomar132/payment-date-dataset"),
    "huggingface/search_erpnext.json": "https://huggingface.co/api/datasets?search=erpnext&limit=20",
    "atomic/github_commit.json": (
        f"https://api.github.com/repos/peplluis7/onemillioninvoices/commits/{ATOMIC_REVISION}"),
    "atomic/README.md": raw_github(
        "peplluis7/onemillioninvoices", ATOMIC_REVISION, "README.md"),
    "atomic/data_schema.md": raw_github(
        "peplluis7/onemillioninvoices", ATOMIC_REVISION, "docs/data_schema.md"),
    "atomic/mendeley_landing.html": "https://data.mendeley.com/datasets/28rbmvwsm9/1",
}

EXPECTED_MISSING = {"erpnext/current_demo_payment_entry.json": 404}


def sha256(payload):
    return hashlib.sha256(payload).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json_exclusive(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def download_snapshot(folder, offline):
    manifest_path = folder / "source_manifest.json"
    spec_hash = sha256(json.dumps(REQUESTS, sort_keys=True).encode())
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        if manifest.get("spec_hash") != spec_hash:
            raise ValueError("Existing snapshot uses a different request specification")
        by_name = {item["file"]: item for item in manifest["responses"]}
        if set(by_name) != set(REQUESTS):
            raise ValueError("Existing snapshot does not cover the request specification")
        for name, item in by_name.items():
            if item["status"] == 200:
                payload = (folder / name).read_bytes()
                if len(payload) != item["bytes"] or sha256(payload) != item["sha256"]:
                    raise ValueError(f"Cached bytes differ for {name}")
        return manifest
    if offline:
        raise ValueError("Offline mode requires an existing complete snapshot")
    if folder.exists() and any(folder.iterdir()):
        raise ValueError("Snapshot directory is non-empty but has no manifest")
    folder.mkdir(parents=True, exist_ok=True)
    responses = []
    for name, url in REQUESTS.items():
        checked = datetime.now(timezone.utc).isoformat()
        request = urllib.request.Request(
            url, headers={"User-Agent": "FinanceProject-T1-ERPNext-Research/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=45) as response:
                payload = response.read(MAX_BYTES + 1)
                if len(payload) > MAX_BYTES:
                    raise ValueError("Response exceeds 12 MB bound")
                target = folder / name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(payload)
                responses.append({"file": name, "url": url, "status": response.status,
                    "checked_at_utc": checked, "bytes": len(payload), "sha256": sha256(payload)})
        except urllib.error.HTTPError as exc:
            responses.append({"file": name, "url": url, "status": exc.code,
                "checked_at_utc": checked, "expected_missing": EXPECTED_MISSING.get(name) == exc.code})
        except (OSError, ValueError) as exc:
            responses.append({"file": name, "url": url, "status": None,
                "checked_at_utc": checked, "error_type": type(exc).__name__, "reason": str(exc)[:240]})
    manifest = {"spec_hash": spec_hash, "use_policy": "inspection_only_not_training_data",
        "responses": responses}
    write_json_exclusive(manifest_path, manifest)
    return manifest


def doctype_fields(path):
    doc = read_json(path)
    return [field.get("fieldname") for field in doc.get("fields", []) if field.get("fieldname")]


def metadata_text(value):
    return json.dumps(value, ensure_ascii=False).lower()


def inspect_erpnext(folder):
    listing = read_json(folder / "erpnext/demo_listing.json")
    current_commit = read_json(folder / "erpnext/current_commit.json")
    removal = read_json(folder / "erpnext/demo_removal_commit.json")
    demo_code = (folder / "erpnext/historical_demo.py").read_text(encoding="utf-8-sig")
    tables = {}
    for name in ("sales_order", "payment_entry", "journal_entry"):
        rows = read_json(folder / f"erpnext/historical_{name}.json")
        tables[name] = len(rows)
    selected = {
        "sales_invoice": ("customer", "posting_date", "due_date", "currency", "grand_total",
            "outstanding_amount", "status", "is_return", "return_against"),
        "payment_entry": ("posting_date", "payment_type", "party_type", "party", "paid_amount",
            "received_amount", "reference_date", "clearance_date", "references"),
        "payment_entry_reference": ("reference_doctype", "reference_name", "due_date", "total_amount",
            "outstanding_amount", "allocated_amount", "exchange_rate", "payment_term"),
        "payment_ledger_entry": ("posting_date", "account_type", "party_type", "party", "voucher_type",
            "voucher_no", "against_voucher_type", "against_voucher_no", "amount", "delinked"),
    }
    schema = {}
    for name, wanted in selected.items():
        fields = doctype_fields(folder / f"erpnext/{name}.json")
        schema[name] = {"field_count": len(fields), "t1_fields_present": [x for x in wanted if x in fields],
            "t1_fields_absent": [x for x in wanted if x not in fields]}
    return {
        "repository": "https://github.com/frappe/erpnext",
        "revision": current_commit["sha"],
        "revision_date": current_commit["commit"]["committer"]["date"],
        "license_file_inspected": True,
        "current_demo_files": sorted(item["name"] for item in listing),
        "current_transaction_demo_files_present": any(
            item["name"] in {"sales_order.json", "payment_entry.json", "journal_entry.json"}
            for item in listing),
        "demo_removal_commit": {"sha": removal["sha"],
            "date": removal["commit"]["committer"]["date"],
            "message": removal["commit"]["message"].splitlines()[0]},
        "pre_removal_revision": ERP_PRE_REMOVAL_REVISION,
        "pre_removal_demo_row_counts": tables,
        "pre_removal_demo_logic": {
            "uses_random_dates": "randint(" in demo_code,
            "invoice_posting_date_assigned_from_order_date": bool(re.search(
                r"invoice\.posting_date\s*=\s*(?:order\.)?transaction_date", demo_code)),
            "invoice_due_date_assigned_from_order_date": bool(re.search(
                r"invoice\.due_date\s*=\s*(?:order\.)?transaction_date", demo_code)),
            "payment_posting_date_assigned_from_order_date": bool(re.search(
                r"payment\.posting_date\s*=\s*(?:order\.)?transaction_date", demo_code)),
        },
        "schema": schema,
        "assessment": (
            "ERPNext supplies a usable extraction schema and software fixtures, but this inspection "
            "found no ERPNext-maintained real-company invoice-payment corpus. Historical transaction "
            "demo rows are generated fixtures and create artificial same-day invoice/payment timing."),
    }


def inspect_kaggle(folder):
    search = read_json(folder / "kaggle/search_erpnext.json")
    ids = []
    for item in search:
        url = item.get("urlNullable") or item.get("url") or ""
        ids.append(url.removeprefix("https://www.kaggle.com/datasets/"))
    specs = {
        "erpnext_sft": ("erpnext_sft.json", "synthetic ERPNext SFT trajectories, not transactions"),
        "global_b2b": ("global_b2b_synthetic.json", "publisher describes synthetic invoices/payments"),
        "ibm_late_payment": ("ibm_late_payment.json", "near-match schema; real-record provenance not established"),
        "highradius_1": ("highradius_1.json", "republished HighRadius-like rows; publisher authority not established"),
        "highradius_2": ("highradius_2.json", "republished HighRadius-like rows; publisher authority not established"),
    }
    candidates = {}
    for key, (filename, assessment) in specs.items():
        value = read_json(folder / f"kaggle/{filename}")
        text = metadata_text(value)
        candidates[key] = {
            "ref": value.get("ref"), "title": value.get("title"),
            "license_name": value.get("licenseName"),
            "total_bytes": value.get("totalBytes"),
            "metadata_mentions_synthetic": "synthetic" in text,
            "metadata_mentions_highradius": "highradius" in text,
            "assessment": assessment,
        }
    return {"erpnext_search_result_count": len(search), "erpnext_search_refs": ids,
        "candidates": candidates,
        "assessment": "No verified ERPNext transaction corpus appeared in the bounded public search."}


def inspect_huggingface(folder):
    rows = read_json(folder / "huggingface/search_erpnext.json")
    return {"search_result_count": len(rows),
        "results": [{"id": row.get("id"), "sha": row.get("sha"), "tags": row.get("tags", [])}
                    for row in rows],
        "assessment": (
            "Results are code, documentation, agent-task or instruction datasets; no result was "
            "verified as invoice-payment transaction microdata.")}


def inspect_atomic(folder):
    schema = (folder / "atomic/data_schema.md").read_text(encoding="utf-8-sig")
    readme = (folder / "atomic/README.md").read_text(encoding="utf-8-sig")
    landing = (folder / "atomic/mendeley_landing.html").read_text(encoding="utf-8-sig")
    commit = read_json(folder / "atomic/github_commit.json")
    fields = re.findall(r"\| `([^`]+)` \|", schema)
    page_text = re.sub(r"<[^>]+>", " ", landing)
    count_match = re.search(r"749[,.]952", page_text)
    return {
        "doi": "10.17632/28rbmvwsm9.1",
        "landing_page": "https://data.mendeley.com/datasets/28rbmvwsm9/1",
        "license": "CC BY 4.0 (dataset landing page)",
        "repository_revision": commit["sha"],
        "repository_revision_date": commit["commit"]["committer"]["date"],
        "published_record_count_claim_found": bool(count_match),
        "schema_fields": fields,
        "paid_or_settlement_date_field_present": any(
            field in {"paid_date", "payment_date", "settlement_date", "clearing_date"} for field in fields),
        "raw_company_exports_distributed": "Raw invoices and reversible company mappings are not included" not in readme,
        "assessment": (
            "Large real-source pseudonymized invoice-obligation dataset with issue/due dates and amount, "
            "but no observed payment-date field. Algorithmic clearing output is not an actual cash-payment label."),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path,
        default=ROOT / f"data/T1/raw/erpnext_source_research/{RESEARCH_DATE}")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--offline", action="store_true")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("Output exists; choose a new --output")
    manifest = download_snapshot(args.input, args.offline)
    unexpected = [item for item in manifest["responses"]
                  if item["status"] != 200 and not item.get("expected_missing")]
    if unexpected:
        raise RuntimeError(f"Unexpected source access failures: {unexpected}")
    report = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "client_research_date": RESEARCH_DATE,
        "script_sha256": sha256(Path(__file__).read_bytes()),
        "scope": (
            "Public metadata and static files only: pinned ERPNext schemas/demo fixtures, bounded Kaggle "
            "and Hugging Face search, and the published Atomic Common-Day Invoice Clearing schema."),
        "manifest": manifest,
        "erpnext": inspect_erpnext(args.input),
        "kaggle": inspect_kaggle(args.input),
        "huggingface": inspect_huggingface(args.input),
        "atomic_common_day": inspect_atomic(args.input),
        "conclusion": {
            "verified_public_erpnext_real_invoice_payment_corpora_found": 0,
            "verified_real_invoice_obligation_near_matches_found": 1,
            "near_match_is_sufficient_for_t1_payment_timing": False,
            "recommended_t1_path": (
                "Use ERPNext Sales Invoice + Payment Entry + Payment Entry Reference/Payment Ledger exports "
                "from a consenting partner, preserve revisions and open items, and keep public observed-paid "
                "benchmarks separate from partner open-portfolio validation."),
        },
        "limits": [
            "Bounded web/API search cannot prove that no suitable dataset exists.",
            "No private ERPNext instance, issue payload or personal/business identifier was collected.",
            "No candidate transaction file was downloaded or audited row by row.",
            "Search metadata and publisher claims do not independently prove business-data provenance.",
            "No training, model evaluation or ERPNext execution was performed.",
        ],
    }
    write_json_exclusive(args.output, report)


if __name__ == "__main__":
    main()
