"""Conditional 13-step simulation with exact reuse of identical histories.

Factors are redrawn independently at each step. Thus their uniforms remain
uniform conditional on prior simulated history; a persistent latent is not
silently inserted into a calibrated Markov transition model.
"""
from __future__ import annotations

import time

import numpy as np
import pandas as pd
from scipy.special import ndtr

from agent1.models import t1
from experiments.t1_competing_v6.features import V6_FEATURES
from .core import OPEN, PathState, advance, origin_view


def conditional_uniforms(rng, n, firm_codes, customer_codes, rho_firm, rho_customer):
    if rho_firm < 0 or rho_customer < 0 or rho_firm+rho_customer > 1:
        raise ValueError("Invalid conditional copula variance")
    m = len(firm_codes)
    latent = np.sqrt(1-rho_firm-rho_customer)*rng.standard_normal((n, m))
    if rho_firm:
        latent += np.sqrt(rho_firm)*rng.standard_normal((n, int(max(firm_codes, default=-1))+1))[:, firm_codes]
    if rho_customer:
        latent += np.sqrt(rho_customer)*rng.standard_normal((n, int(max(customer_codes, default=-1))+1))[:, customer_codes]
    return ndtr(latent)


def simulate_receipts(model, frame, *, n=1000, seed=0, rho_firm=.15, rho_customer=.15,
                      max_invoices=2000, return_invoice_cash=False):
    start = time.perf_counter()
    origin = origin_view(frame)
    m = len(origin)
    if m > max_invoices or n < 1:
        raise ValueError("Simulation exceeds the locked invoice/path budget")
    if m and pd.to_datetime(origin.cutoff).nunique() != 1:
        raise ValueError("A rollout requires one common forecast origin")
    rng = np.random.default_rng(seed)
    inflow = np.zeros((n, 13))
    detailed = np.zeros((n, m, 13)) if return_invoice_cash else None
    invoice_index = np.arange(m)
    groups = np.broadcast_to(invoice_index, (n, m)).copy()
    state = PathState.start(m)
    firm, _ = pd.factorize(origin.firm_id, sort=True)
    customer, _ = pd.factorize(pd.MultiIndex.from_frame(origin[["firm_id", "customer_id"]]), sort=True)
    base = origin[V6_FEATURES].to_numpy(np.float32)
    amounts = origin.amount_open.to_numpy(float)
    vocabulary = model.vocabulary
    cash = np.array([v["cash_fraction"] for v in vocabulary])
    credit = np.array([v["credit_fraction"] for v in vocabulary])
    status = np.array([v["status"] for v in vocabulary])
    order = sorted(range(len(vocabulary)), key=lambda j: (cash[j], credit[j], status[j]))
    if order != list(range(len(vocabulary))):
        raise ValueError("Transition outcomes must be ordered by representative cash")
    audit = []
    for week in range(1, 14):
        rows, cols = np.nonzero(groups >= 0)
        if not len(rows):
            break
        wf = t1._week_feats(origin, week)
        calendar = np.column_stack([wf[c] for c in t1.WEEK_FEATS]).astype(np.float32)
        # Group identity contains origin invoice and complete discrete history.
        # No approximate rounding or shared-company context update is used.
        x = np.column_stack((base[invoice_index], calendar[invoice_index], state.matrix())).astype(np.float32)
        probability = model.predict(x)
        previous = groups[rows, cols]
        uniforms = conditional_uniforms(rng, n, firm, customer, rho_firm, rho_customer)[rows, cols]
        cdf = np.cumsum(probability, axis=1)
        chosen = np.zeros(len(rows), dtype=np.int16)
        for j in range(len(vocabulary)-1):
            chosen += uniforms > cdf[previous, j]
        received = amounts[cols]*state.remaining[previous]*cash[chosen]
        inflow[:, week-1] = np.bincount(rows, weights=received, minlength=n)
        if detailed is not None:
            detailed[rows, cols, week-1] = received
        # Exact histories represented once; each path still gets its own draw.
        code, inverse = np.unique(previous*len(vocabulary)+chosen, return_inverse=True)
        old, outcome = code//len(vocabulary), code % len(vocabulary)
        newstate = state.take(old)
        opening = newstate.remaining.copy()
        rc, cr, wo = advance(newstate, np.arange(len(code)), cash[outcome], credit[outcome], status[outcome])
        residual = opening-rc-cr-wo-newstate.remaining
        live = newstate.status == OPEN
        mapping = np.full(len(code), -1, dtype=int)
        mapping[live] = np.arange(live.sum())
        groups[rows, cols] = mapping[inverse]
        audit.append({"week": week, "active_path_invoice_rows": len(rows), "predicted_unique_histories": len(x),
                      "max_accounting_error_vnd": float(np.max(np.abs(residual)*amounts[invoice_index[old]], initial=0)),
                      "min_remaining_ratio": float(np.min(newstate.remaining, initial=0)),
                      "cash_vnd": float(received.sum()),
                      "noncash_credit_ratio_sum_over_unique_histories": float(cr.sum()),
                      "writeoff_ratio_sum_over_unique_histories": float(wo.sum())})
        invoice_index = invoice_index[old[live]]
        state = newstate.take(np.flatnonzero(live))
    return {"cash": inflow, "invoice_cash": detailed, "audit": audit,
            "seconds": time.perf_counter()-start, "paths": n, "invoices": m,
            "predicted_rows": sum(a["predicted_unique_histories"] for a in audit),
            "active_rows": sum(a["active_path_invoice_rows"] for a in audit)}
