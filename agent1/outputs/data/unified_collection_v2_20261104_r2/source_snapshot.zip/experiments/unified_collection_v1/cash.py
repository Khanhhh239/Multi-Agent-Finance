"""Private paired T6 adapter; the existing service/simulator is never edited."""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.special import ndtr

from agent1.models import t4_revenue as T4
from agent1.models.t6_cash import collection_kernel, simulate

FIXED = {"payroll_net", "social_insurance", "rent", "loan_service", "license_fee"}
ESTIMATED = {"vat", "cit_provisional", "tet_bonus", "utilities"}


def weekly(series, cutoff):
    return np.array([series[(series.index > cutoff+pd.Timedelta(days=7*k)) &
                            (series.index <= cutoff+pd.Timedelta(days=7*(k+1)))].sum() for k in range(13)])


def known_outflows(outflows, cutoff):
    """Same dated T5 rules as scripts/run_t6.py; no import-time output writes."""
    fixed = outflows[outflows.category.isin(FIXED)].groupby("date").amount.sum()
    result = weekly(fixed, cutoff)
    for category, group in outflows[outflows.category.isin(ESTIMATED)].groupby("category"):
        hist = group[group.date.le(cutoff)]
        estimate = float(hist.amount.tail(4).mean()) if len(hist) else 0.
        future = group[group.date.gt(cutoff)].copy()
        if category in {"vat", "cit_provisional"}:
            known_at = future.date.dt.to_period("M").dt.start_time
            future["forecast"] = np.where(known_at.le(cutoff), future.amount, estimate)
        else:
            future["forecast"] = estimate
        result += weekly(future.groupby("date").forecast.sum(), cutoff)
    supplier = outflows[outflows.category.eq("supplier")].groupby("date").amount.sum()
    result += supplier[(supplier.index < cutoff) & (supplier.index >= cutoff-pd.Timedelta(days=91))].sum()/13
    if "known_at" in outflows:
        known = outflows[outflows.category.eq("supplier") & outflows.known_at.le(cutoff)].groupby("date").amount.sum()
        history = supplier[(supplier.index < cutoff) & (supplier.index >= cutoff-pd.Timedelta(days=91))].sum()/13
        result[:4] += weekly(known, cutoff)[:4]-history
    return result


def revenue_history(invoices, cutoff):
    # Complete calendar weeks only. Post-origin issue dates cannot extend history.
    current_monday = cutoff.normalize()-pd.Timedelta(days=cutoff.dayofweek)
    known = invoices[invoices.issue_date.lt(current_monday)].copy()
    if known.empty:
        return pd.Series(dtype=float)
    known["week"] = known.issue_date.dt.to_period("W-SUN").dt.start_time
    s = known.groupby("week").amount_gross.sum()
    return s.reindex(pd.date_range(s.index.min(), current_monday-pd.Timedelta(days=7), freq="7D"), fill_value=0.)


def revenue_quantiles(models, invoices, cutoff):
    series = revenue_history(invoices, cutoff)
    if len(series) < 30:
        return None
    weeks = pd.date_range(series.index[0], periods=len(series)+13, freq="7D")
    x, _, meta = T4.make_rows(series.to_numpy(), weeks, True, [len(series)-1], with_target=False)
    return np.sort(np.column_stack([models[q].predict(x, num_threads=4) for q in T4.QS]), axis=1).clip(0)*meta[:, 2:3]


def common_cash_inputs(invoices, outflows, daily, cutoff, t4, paths, seed):
    history = daily[daily.date.le(cutoff)].set_index("date")
    if history.empty:
        raise ValueError("No observed opening cash balance")
    b0 = float(history.balance.iloc[-1])
    out = known_outflows(outflows, cutoff)
    rev = revenue_quantiles(t4, invoices, cutoff)
    kernel = collection_kernel(invoices[invoices.issue_date.le(cutoff)], cutoff)
    rng = np.random.default_rng(seed)
    future_cash = np.zeros((paths, 13))
    if rev is not None:
        v = ndtr(rng.standard_normal((paths, 13)))
        q10, q50, q90 = rev.T
        amount = np.maximum(0, np.where(v < .5, q10+(q50-q10)*(v-.1)/.4,
                                       q50+(q90-q50)*(v-.5)/.4))
        for j in range(13):
            for d in range(13-j):
                future_cash[:, j+d] += amount[:, j]*kernel[d]
    draw = {}
    recent = history[history.index > cutoff-pd.Timedelta(days=365)]
    ends = recent[recent.index.is_quarter_end]
    positive = ends.owner_draw.gt(0)
    if positive.any():
        target = float(ends.loc[positive, "balance"].median())
        pre = ends.balance+ends.owner_draw
        upper = float(pre[positive].min())
        lower = max(target, float(pre[~positive].max())) if (~positive).any() else target
        cap = max(target, (lower+upper)/2)
        dates = pd.date_range(cutoff+pd.Timedelta(days=1), cutoff+pd.Timedelta(days=91))
        ends_future = dates[dates.is_quarter_end]
        mask = np.array([((ends_future > cutoff+pd.Timedelta(days=7*k)) &
                          (ends_future <= cutoff+pd.Timedelta(days=7*(k+1)))).any() for k in range(13)])
        draw = {"cap": cap, "target": target, "weeks": mask}
    # Future daily cash is read solely for truth, after all forecast inputs exist.
    data = daily.set_index("date")
    net = data.inflow_ar+data.inflow_other-data.outflow-data.owner_draw
    truth = b0+np.cumsum(weekly(net, cutoff))
    return {"b0": b0, "known_out": out, "new_cash": future_cash, "draw": draw,
            "truth": truth, "scale": max(float(out.mean()), 1.)}


def balance_paths(open_cash, context):
    net = open_cash+context["new_cash"]-context["known_out"][None, :]
    balance = np.empty_like(net)
    running = np.full(len(net), context["b0"])
    draw = context["draw"]
    for k in range(13):
        running += net[:, k]
        if draw and draw["weeks"][k]:
            withdrawal = np.where(running > draw["cap"], np.maximum(running-draw["target"], 0.), 0.)
            running -= withdrawal
        balance[:, k] = running
    return balance


def v6_receipts(frame, paid_pmf, paths, seed, rho_firm, rho_customer):
    # Existing fixed v6 lump-sum baseline. No T2 draw or cash-head addition.
    _, cash = simulate(frame, paid_pmf, 0., np.zeros(13), None, np.zeros(17), 0., [],
                       n=paths, rho=rho_firm, rho_customer=rho_customer, seed=seed)
    return cash
