"""Versioned prototype: lock -> label/fit -> calibrate -> latency -> paired T6.

Run from the project root with python -B -m experiments.unified_collection_v1.run.
Every artifact is exclusive and all prior versions are protected by hashes.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
from pathlib import Path
import platform
import time
import zipfile

import lightgbm as lgb
import numpy as np
import pandas as pd

from agent1.data.world_manifest import code_provenance, create_world_manifest, load_cohort, sha256_file, verify_world_manifest
from agent1.models import t4_revenue as T4
from agent1.paths import ROOT, SYNTH
from agent1.synth.shocks import ShockEpisode
from agent1.synth.world import World, WorldConfig
from experiments.t1_competing_v6.core import cumulative_states, predict_hazards
from experiments.t1_competing_v6.calibration import transform as calibrate_v6
from experiments.t1_competing_v6.features import V6SnapshotBuilder, model_view
from experiments.t1_competing_v6.run import balanced_sample, write_bytes_once, write_csv, write_json, write_parquet
from .cash import balance_paths, common_cash_inputs, revenue_history, v6_receipts
from .core import FEATURES, LabelIndex, encode, fit_vocabulary, observed_rows, origin_view
from .metrics import paired_summary, research_decision, score_paths
from .model import TransitionModel, fit_calibration, log_loss
from .rollout import simulate_receipts

HERE = Path(__file__).resolve().parent
PROTOCOL = HERE/"protocol.json"


def sources():
    files = list(HERE.glob("*.py")) + [PROTOCOL, HERE/"README.md", ROOT/"tests/test_unified_collection_v1.py"]
    # Imported dependencies are protected too, including the existing generator.
    files += list((ROOT/"agent1").rglob("*.py"))
    files += list((ROOT/"experiments/t1_competing_v6").glob("*.py"))
    files += list((ROOT/"experiments/t1_competing_v5").glob("*.py"))
    return {p.relative_to(ROOT).as_posix(): sha256_file(p) for p in sorted(set(files))}


def protected_files():
    directories = [ROOT/f"experiments/t1_competing_{v}" for v in ("v5", "v6")]
    directories += [ROOT/"outputs/data"/v for v in ("v4_shortpay_4shock_20261028", "v5_competing_risks_53w_20261028", "t1_competing_v6_20261101")]
    directories += list(SYNTH.glob("v4_shortpay_4shock_20261028*"))+list(SYNTH.glob("v6_holdout_20261101*"))
    files = []
    for d in directories:
        files += [d] if d.is_file() else [p for p in d.rglob("*") if p.is_file() and "__pycache__" not in p.parts]
    return {p.relative_to(ROOT).as_posix(): sha256_file(p) for p in sorted(set(files))}


def prepare(p):
    out = (ROOT/p["output_directory"]).resolve()
    if out.parent != (ROOT/"outputs/data").resolve() or not out.name.startswith("unified_collection_v1_"):
        raise ValueError("Output must be in the isolated versioned prototype directory")
    cohort = load_cohort(ROOT/p["source_cohort"])
    raw = json.loads((ROOT/"data/raw/MANIFEST.json").read_text(encoding="utf-8"))
    for source in raw.values():
        for file in source["files"]:
            if sha256_file(ROOT/"data/raw"/file["path"]) != file["sha256"]:
                raise ValueError("Raw generator input differs from current manifest")
    write_json(out/"protocol.lock.json", p)
    write_json(out/"source_hashes.json", sources())
    write_json(out/"preservation_before.json", protected_files())
    for v, name in (("v4", "v4_shortpay_4shock_20261028"), ("v5", "v5_competing_risks_53w_20261028"), ("v6", "t1_competing_v6_20261101")):
        directory = ROOT/"outputs/data"/name
        meta = json.loads((directory/"train.json").read_text(encoding="utf-8"))
        if sha256_file(directory/"model.txt") != meta["model_sha256"]:
            raise ValueError(f"Changed {v} baseline model")
    environment = {"python": platform.python_version(), "packages": {n: importlib.metadata.version(n) for n in ("numpy", "pandas", "lightgbm", "scipy", "pyarrow", "pytest")}}
    write_json(out/"environment.json", environment)
    archive = out/"source_snapshot.zip"
    if not archive.exists():
        with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED) as z:
            for relative in sources():
                z.write(ROOT/relative, relative)
    return out, cohort


def anchors(out, entry, p):
    world = entry["name"]
    if entry["role"] != "train":
        raise ValueError("Only source train Worlds may supply fitting anchors")
    cache = out/"cache"/f"anchors_{world}.parquet"
    if cache.exists():
        return pd.read_parquet(cache)
    old = ROOT/p["v6_directory"]/"cache"/f"train_{world}.parquet"
    detail = json.loads(old.with_suffix(".json").read_text(encoding="utf-8"))
    if sha256_file(old) != detail["cache_sha256"]:
        raise ValueError("Changed existing v6 source cache")
    full = pd.read_parquet(old)
    parts = []
    for partition in ("fit", "calibration_fit", "calibration_select"):
        cap = p["max_fit_anchors_per_world"] if partition == "fit" else p["max_calibration_anchors_per_partition_world"]
        parts.append(balanced_sample(full[full.partition.eq(partition)].reset_index(drop=True), cap, p["seed"]))
    selected = pd.concat(parts, ignore_index=True)
    if selected.groupby("firm_id").partition.nunique().gt(1).any():
        raise ValueError("Source firm partitions overlap")
    write_parquet(cache, selected)
    write_json(cache.with_suffix(".json"), {"world": world, "v6_anchor_sha256": sha256_file(old), "selected_sha256": sha256_file(cache),
                                          "partition_counts": selected.groupby("partition").size().to_dict()})
    return selected


def source_data(out, cohort, p, partitions):
    values = {name: [[], [], [], []] for name in partitions}
    for entry in cohort["worlds"]:
        if entry["role"] != "train":
            continue
        world = entry["name"]
        selected = anchors(out, entry, p)
        inv = pd.read_parquet(SYNTH/world/"invoices.parquet")
        pay = pd.read_parquet(SYNTH/world/"payments.parquet")
        labels = LabelIndex(inv, pay)
        for name in partitions:
            frame = selected[selected.partition.eq(name)].reset_index(drop=True)
            result = observed_rows(frame, labels, p["train_label_end"], p["partial_fraction_edges"])
            for i, value in enumerate(result):
                values[name][i].append(value)
            print(f"{world} {name}: {len(frame):,} anchors -> {len(result[0]):,} transition rows", flush=True)
    return {name: tuple(pd.concat(v, ignore_index=True) if i == 3 else np.concatenate(v) for i, v in enumerate(parts))
            for name, parts in values.items()}


def train(out, cohort, p):
    meta_file = out/"train.json"
    if meta_file.exists():
        meta = json.loads(meta_file.read_text(encoding="utf-8"))
        if sha256_file(out/"model.txt") != meta["model_sha256"]:
            raise ValueError("Changed transition model")
        return meta
    x, keys, pairs, detail = source_data(out, cohort, p, ["fit"])["fit"]
    vocabulary = fit_vocabulary(keys, pairs)
    y = encode(keys, vocabulary)
    if len(vocabulary) < 2:
        raise ValueError("Insufficient outcome support for a joint classifier")
    start = time.perf_counter()
    booster = lgb.train({**p["lightgbm"], "num_class": len(vocabulary)},
                        lgb.Dataset(x, y, feature_name=FEATURES), num_boost_round=p["rounds"])
    write_bytes_once(out/"model.txt", booster.model_to_string().encode("utf-8"))
    representative = np.array([[v["cash_fraction"], v["credit_fraction"]] for v in vocabulary])[y]
    amount_error = np.abs(representative-pairs)*detail.opening.to_numpy()[:, None]
    write_json(out/"discretization.json", {
        "scope": "train-only teacher-forced quantization; not forecast skill or generated-path error",
        "cash_absolute_error_vnd": float(amount_error[:, 0].sum()),
        "cash_wape": float(amount_error[:, 0].sum()/max(detail.cash_actual.sum(), 1)),
        "credit_absolute_error_vnd": float(amount_error[:, 1].sum()),
        "partial_cash_rows": int(((pairs[:, 0] > 0) & (pairs[:, 0] < 1)).sum()),
        "max_joint_fraction": float(representative.sum(1).max()),
        "exact_zero_and_full_atoms": True})
    support = detail.assign(outcome=y).groupby(["world", "outcome"]).agg(rows=("outcome", "size"), firms=("firm_id", "nunique"), invoices=("invoice_id", "nunique")).reset_index()
    write_csv(out/"train_label_support.csv", support)
    meta = {"version": p["version"], "features": FEATURES, "vocabulary": vocabulary,
            "n_transition_rows": len(y), "fit_worlds": sorted(detail.world.unique()),
            "fit_firms": int(detail.groupby("world").firm_id.nunique().sum()),
            "credit_only_risk_learned": any(v["status"] == 3 for v in vocabulary),
            "natural_frequency_training": True, "train_seconds": time.perf_counter()-start,
            "model_sha256": sha256_file(out/"model.txt"), "protocol_sha256": sha256_file(PROTOCOL)}
    write_json(meta_file, meta)
    return meta


def calibrate(out, cohort, p, meta):
    path = out/"calibration.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    source = source_data(out, cohort, p, ["calibration_fit", "calibration_select"])
    model = TransitionModel(lgb.Booster(model_file=str(out/"model.txt")), meta["vocabulary"])
    inputs, sizes = [], {}
    for name in ("calibration_fit", "calibration_select"):
        x, keys, _, _ = source[name]
        inputs.extend((model.predict(x), encode(keys, meta["vocabulary"], allow_unknown=True)))
        sizes[name] = len(x)
    calibration = fit_calibration(*inputs, p["calibration"])
    calibration["source_rows"] = sizes
    calibration["fit_scope"] = "disjoint source calibration firms; no holdout outcomes"
    write_json(path, calibration)
    return calibration


def load_model(out, meta, calibration, p):
    if sha256_file(out/"model.txt") != meta["model_sha256"]:
        raise ValueError("Transition model hash mismatch")
    return TransitionModel(lgb.Booster(model_file=str(out/"model.txt")), meta["vocabulary"], calibration, p["simulation"]["batch_rows"])


def latency(out, cohort, p, model):
    path = out/"latency.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    world = next(e["name"] for e in cohort["worlds"] if e["role"] == "train")
    inv, pay, prom = (pd.read_parquet(SYNTH/world/f"{name}.parquet") for name in ("invoices", "payments", "promises"))
    cutoff = pd.Timestamp(p["evaluation_cutoffs"][0])
    view = model_view(V6SnapshotBuilder(inv, pay, prom).snapshot(cutoff), cutoff)
    count = p["simulation"]["max_invoices"]
    if len(view) < count:
        raise ValueError("Insufficient real origin anchors for full-budget benchmark")
    view = view.sort_values("invoice_id").iloc[:count]
    result = simulate_receipts(model, view, n=p["simulation"]["paths"], seed=p["seed"],
                               rho_firm=p["simulation"]["rho_firm"], rho_customer=p["simulation"]["rho_customer"], max_invoices=count)
    report = {k: v for k, v in result.items() if k not in ("cash", "invoice_cash")}
    report["passed"] = report["seconds"] <= p["acceptance"]["max_latency_seconds_1000x2000"]
    report["scope"] = "actual 13-step transition rollout on 2000 source anchors at one cutoff, possibly multiple firms; includes feature assembly and sampling, excludes data loading and T4/T5"
    report["max_prediction_batch_float32_mib"] = p["simulation"]["batch_rows"]*len(FEATURES)*4/1024**2
    write_json(path, report)
    print(f"full-budget rollout: {report['seconds']:.2f}s, {report['predicted_rows']:,} unique history predictions, passed={report['passed']}", flush=True)
    return report


def train_t4(out, cohort, p):
    meta_file = out/"t4.json"
    if not meta_file.exists():
        xs, ys = [], []
        for entry in cohort["worlds"]:
            if entry["role"] != "train":
                continue
            fit_firms = anchors(out, entry, p).query("partition == 'fit'").firm_id.unique()
            inv = pd.read_parquet(SYNTH/entry["name"]/"invoices.parquet")
            for fid in sorted(fit_firms):
                s = revenue_history(inv[inv.firm_id.eq(fid)], pd.Timestamp(p["t4"]["fit_end"]))
                x, y, _ = T4.make_rows(s.to_numpy(), s.index, True,
                                       range(20, len(s)-13, p["t4"]["origin_stride_weeks"]))
                if len(x):
                    xs.append(x)
                    ys.append(y)
        x, y = np.concatenate(xs), np.concatenate(ys)
        hashes = {}
        for q in T4.QS:
            model = lgb.train({"objective": "quantile", "alpha": q, "learning_rate": .04,
                               "num_leaves": 31, "min_data_in_leaf": 50, "verbose": -1,
                               "seed": p["seed"], "num_threads": 4, "deterministic": True, "force_col_wise": True},
                              lgb.Dataset(x, y, feature_name=T4.FEATS), p["t4"]["rounds"])
            file = out/f"t4_q{int(q*100)}.txt"
            write_bytes_once(file, model.model_to_string().encode("utf-8"))
            hashes[file.name] = sha256_file(file)
        write_json(meta_file, {"rows": len(y), "fit_roles": ["train"], "hashes": hashes,
                              "paired": "one set of source-only models shared by both collection processes"})
    meta = json.loads(meta_file.read_text(encoding="utf-8"))
    if any(sha256_file(out/name) != digest for name, digest in meta["hashes"].items()):
        raise ValueError("Changed paired T4 models")
    return {q: lgb.Booster(model_file=str(out/f"t4_q{int(q*100)}.txt")) for q in T4.QS}


def fresh_worlds(out, cohort, p):
    registry = out/"fresh_holdout_registry.json"
    if registry.exists():
        return json.loads(registry.read_text(encoding="utf-8"))
    entries = []
    for entry in p["fresh_holdouts"]:
        directory = SYNTH/entry["name"]
        config = json.loads((SYNTH/entry["template"]/"config.json").read_text(encoding="utf-8"))
        config.update(name=entry["name"], seed=entry["seed"], n_firms=entry["n_firms"], write_xml=0)
        if (directory/"manifest.json").exists():
            manifest = verify_world_manifest(directory)
            if manifest["config"] != config:
                raise ValueError("Fresh configuration differs from locked protocol")
        elif directory.exists():
            raise ValueError("Incomplete fresh directory: refusing overwrite")
        else:
            print(f"Generating locked fresh World {entry['name']}", flush=True)
            parsed = {**config, "shock_schedule": [ShockEpisode(**s) for s in config["shock_schedule"]]}
            World(WorldConfig(**parsed)).run(directory)
            manifest = create_world_manifest(directory, {**code_provenance(), "source_data_sha256": cohort["source_data_sha256"]})
        entries.append({"name": entry["name"], "role": "fresh_test", "seed": manifest["seed"], "manifest_sha256": sha256_file(directory/"manifest.json")})
    write_json(registry, entries)
    return entries


def evaluate(out, entries, p, meta, model, t4, scope):
    destination = out/scope
    if (destination/"summary.csv").exists():
        return pd.read_csv(destination/"summary.csv")
    v6dir = ROOT/p["v6_directory"]
    v6meta = json.loads((v6dir/"train.json").read_text(encoding="utf-8"))
    v6cal = json.loads((v6dir/"calibration.json").read_text(encoding="utf-8"))
    v6 = lgb.Booster(model_file=str(v6dir/"model.txt"))
    rows, weekly_rows, audits, support, dependence = [], [], [], [], []
    sim = p["simulation"]
    for entry in entries:
        world = entry["name"]
        if entry["role"] == "train":
            raise ValueError("Holdout evaluation cannot include fitting Worlds")
        inv, pay, prom, outflows, daily = (pd.read_parquet(SYNTH/world/f"{name}.parquet") for name in
                                          ("invoices", "payments", "promises", "outflows", "daily_cash"))
        episodes = json.loads((SYNTH/world/"config.json").read_text(encoding="utf-8"))["shock_schedule"]
        builder = V6SnapshotBuilder(inv, pay, prom)
        labels = LabelIndex(inv, pay)
        firms = sorted(inv.firm_id.unique())
        if scope == "diagnostic":
            firms = sorted(firms, key=lambda fid: __import__("hashlib").sha256(f"{p['seed']}:{world}:{fid}".encode()).hexdigest())[:p["diagnostic_firms_per_world"]]
        for cutoff in map(pd.Timestamp, p["evaluation_cutoffs"]):
            raw = builder.snapshot(cutoff, firms=firms)
            view = model_view(raw, cutoff) if len(raw) else raw
            for fid in firms:
                part = view[view.firm_id.eq(fid)].reset_index(drop=True)
                if len(part) > sim["max_invoices"]:
                    raise ValueError("Company exceeds locked budget; do not silently truncate its ledger")
                context = common_cash_inputs(inv[inv.firm_id.eq(fid)], outflows[outflows.firm_id.eq(fid)],
                                             daily[daily.firm_id.eq(fid)], cutoff, t4, sim["paths"], p["seed"])
                result = simulate_receipts(model, part, n=sim["paths"], seed=p["seed"], rho_firm=sim["rho_firm"], rho_customer=sim["rho_customer"],
                                           max_invoices=sim["max_invoices"], return_invoice_cash=True)
                if len(part):
                    h = calibrate_v6(predict_hazards(v6, part, v6meta["features"], v6meta["active_causes"]), v6cal)
                    paid_cif = cumulative_states(h)[:, :13, 1]
                    pmf = np.diff(np.column_stack((np.zeros(len(part)), paid_cif)), axis=1)
                    baseline = v6_receipts(part, pmf, sim["paths"], p["seed"], sim["rho_firm"], sim["rho_customer"])
                    _, actual_invoice, _, _ = labels.weekly(part, "2025-12-31")
                    actual = actual_invoice.sum(0)
                    customer_amount = part.groupby("customer_id").amount_open.sum().sort_values(ascending=False)
                    top = customer_amount.head(max(1, int(np.ceil(len(customer_amount)*.2)))).index
                    top_mask = part.customer_id.isin(top).to_numpy()
                    top_actual = actual_invoice[top_mask].sum(0)
                    top_new = result["invoice_cash"][:, top_mask].sum(1).mean(0)
                    top_old = (pmf[top_mask]*part.amount_open.to_numpy()[top_mask, None]).sum(0)
                    cust_codes, customers = pd.factorize(part.customer_id, sort=True)
                    for k in range(13):
                        actual_customer = np.bincount(cust_codes, weights=actual_invoice[:, k], minlength=len(customers))
                        sampled_customer = np.zeros((sim["paths"], len(customers)))
                        for j in range(len(part)):
                            sampled_customer[:, cust_codes[j]] += result["invoice_cash"][:, j, k]
                        z = (actual_customer <= 1).sum()
                        sz = (sampled_customer <= 1).sum(1)
                        count = len(customers)
                        dependence.append({"world": world, "firm_id": fid, "cutoff": cutoff.date().isoformat(), "week": k+1,
                                           "origin_customers": count, "actual_zero_receipt_customer_share": float(z/count),
                                           "simulated_zero_receipt_customer_share": float((sz/count).mean()),
                                           "actual_customer_pair_both_zero": float(z*(z-1)/(count*(count-1))) if count > 1 else None,
                                           "simulated_customer_pair_both_zero": float((sz*(sz-1)/(count*(count-1))).mean()) if count > 1 else None,
                                           "scope": "zero receipts among origin customers, including already closed invoices; descriptive dependence diagnostic"})
                else:
                    baseline, actual = np.zeros_like(result["cash"]), np.zeros(13)
                    top_actual, top_new, top_old = np.zeros(13), np.zeros(13), np.zeros(13)
                key = {"world": world, "role": entry["role"], "firm_id": fid, "cutoff": cutoff.date().isoformat()}
                for name, receipts in (("v6", baseline), ("unified", result["cash"])):
                    balances = balance_paths(receipts, context)
                    rows.append({**key, "model": name, "invoices": len(part), "scale": context["scale"],
                                 **score_paths(balances, context["truth"], context["scale"])})
                    q = np.quantile(balances, [.1, .5, .9], axis=0)
                    for k in range(13):
                        left, right = cutoff+pd.Timedelta(days=7*k), cutoff+pd.Timedelta(days=7*(k+1))
                        shock = any(pd.Timestamp(e["start"]) < right and
                                    pd.Timestamp(e["start"])+pd.Timedelta(weeks=e["rise_weeks"]+e["peak_weeks"]+e["recovery_weeks"]) > left for e in episodes)
                        weekly_rows.append({**key, "model": name, "week": k+1, "cash_actual": float(actual[k]),
                                            "cash_mean": float(receipts[:, k].mean()), "balance_true": float(context["truth"][k]),
                                            "p10": float(q[0, k]), "p50": float(q[1, k]), "p90": float(q[2, k]),
                                            "scheduled_shock": shock, "top20pct_customer_cash_actual": float(top_actual[k]),
                                            "top20pct_customer_cash_mean": float((top_old if name == "v6" else top_new)[k])})
                audits.append({**key, "seconds": result["seconds"], "predicted_rows": result["predicted_rows"],
                               "max_accounting_error_vnd": max((a["max_accounting_error_vnd"] for a in result["audit"]), default=0.)})
                if len(part):
                    x, keys, _, detail = observed_rows(part, labels, "2025-12-31", p["partial_fraction_edges"])
                    y = encode(keys, meta["vocabulary"], allow_unknown=True)
                    prob = model.predict(x)
                    known = y >= 0
                    support.append({**key, "observed_transition_rows": len(y), "unsupported_outcome_rows": int((~known).sum()),
                                    "known_outcome_logloss": log_loss(prob[known], y[known]) if known.any() else None,
                                    "actual_zero_receipt_week_share": float(detail.cash_actual.eq(0).mean())})
                print(f"{scope}: {world} {fid} {cutoff.date()} ({len(part)} invoices, {result['seconds']:.2f}s)", flush=True)
    frame = pd.DataFrame(rows)
    summary, ci = paired_summary(frame, p)
    write_csv(destination/"company_scores.csv", frame)
    write_csv(destination/"weekly_predictions.csv", pd.DataFrame(weekly_rows))
    write_csv(destination/"rollout_audit.csv", pd.DataFrame(audits))
    write_csv(destination/"outcome_support.csv", pd.DataFrame(support))
    write_csv(destination/"customer_dependence.csv", pd.DataFrame(dependence))
    cash_scores = []
    weekly_frame = pd.DataFrame(weekly_rows)
    for (world, name), group in weekly_frame.groupby(["world", "model"]):
        for horizon in (4, 13):
            g = group[group.week.le(horizon)]
            for prefix, suffix in (("", "all_origin_customers"), ("top20pct_customer_", "top20pct_customers_by_origin_amount")):
                actual, predicted = g[prefix+"cash_actual"], g[prefix+"cash_mean"]
                cash_scores.append({"world": world, "model": name, "weeks": horizon, "subgroup": suffix,
                                    "weekly_cash_wape": float(np.abs(predicted-actual).sum()/max(actual.sum(), 1)),
                                    "cash_bias": float((predicted-actual).sum()/max(actual.sum(), 1))})
    write_csv(destination/"cash_scores.csv", pd.DataFrame(cash_scores))
    write_csv(destination/"company_bootstrap.csv", ci)
    write_csv(destination/"summary.csv", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=["prepare", "train", "calibrate", "benchmark", "diagnostic", "fresh", "all"], default="all")
    args = parser.parse_args()
    p = json.loads(PROTOCOL.read_text(encoding="utf-8"))
    out, cohort = prepare(p)
    if args.stage == "prepare":
        return
    meta = train(out, cohort, p)
    if args.stage == "train":
        return
    calibration = calibrate(out, cohort, p, meta)
    if args.stage == "calibrate":
        return
    model = load_model(out, meta, calibration, p)
    timing = latency(out, cohort, p, model)
    if args.stage == "benchmark":
        return
    if not timing["passed"]:
        write_json(out/"decision.json", {"decision": "insufficient_evidence_to_replace_v6", "reason": "full-budget latency failed; no larger fit or fresh evaluation", "service_changed": False})
        return
    t4 = train_t4(out, cohort, p)
    if args.stage in ("diagnostic", "all"):
        entries = [e for e in cohort["worlds"] if e["role"] != "train"]
        entries += [{"name": f"v6_holdout_20261101_{i:03}", "role": "old_fresh_test"} for i in range(2)]
        evaluate(out, entries, p, meta, model, t4, "diagnostic")
        if args.stage == "diagnostic":
            return
    entries = fresh_worlds(out, cohort, p)
    summary = evaluate(out, entries, p, meta, model, t4, "fresh_test")
    audit = pd.read_csv(out/"fresh_test/rollout_audit.csv")
    decision = research_decision(summary, p, timing["passed"], audit.max_accounting_error_vnd.le(p["acceptance"]["money_tolerance_vnd"]).all())
    after = protected_files()
    before = json.loads((out/"preservation_before.json").read_text(encoding="utf-8"))
    if after != before:
        raise ValueError("Protected v4/v5/v6 files changed")
    write_json(out/"preservation_after.json", after)
    write_json(out/"verification.json", {"protected_files_unchanged": True, "protected_files": len(after),
                                        "source_hashes_unchanged": sources() == json.loads((out/"source_hashes.json").read_text(encoding="utf-8")),
                                        "final_worlds": [e["name"] for e in entries], "final_firms": 8,
                                        "scope": "small synthetic prototype; no real-ledger generalization or product acceptance"})
    write_json(out/"decision.json", decision)
    print(json.dumps(decision, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
