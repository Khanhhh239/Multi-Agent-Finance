"""Isolated research prototype for weekly cash/closure transitions."""
