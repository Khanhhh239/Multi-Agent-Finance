"""Prepare one fresh World only after final source model selection is frozen."""
import argparse
from pathlib import Path
import json

import pandas as pd

from experiments.t1_v6_practical.run import ROOT, prepare, digest, json_once, make_world, load_world, build_frame, attach, save_frame, read_frame


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world-index", required=True, type=int, choices=range(4))
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/data/t1_v6_practical_20261105_r2")
    args = parser.parse_args()
    out = args.output.resolve()
    if not out.is_relative_to((ROOT / "outputs/data").resolve()):
        raise ValueError("Use an isolated experiment directory")
    lock = out / "final_selection.lock.json"
    if not lock.exists():
        raise ValueError("No fresh generation before final source selection freeze")
    spec, _ = prepare(out)
    selection = json.loads(lock.read_text(encoding="utf-8"))
    if digest(out / "protocol.lock.json") != selection["protocol_sha256"]:
        raise ValueError("Fresh protocol differs from final selection lock")
    if any(digest(out / "models" / f"{name}.txt") != value for name, value in selection["models_sha256"].items()):
        raise ValueError("A model changed after final freeze")
    cfg = spec["fresh_worlds"][args.world_index]
    path = out / "prepared" / f"{cfg['name']}_fresh.parquet"
    if path.exists():
        read_frame(path)
        return
    make_world(out, cfg)
    builder, _ = load_world(cfg["name"])
    dates = pd.date_range(spec["eval_first_cutoff"], spec["eval_last_cutoff"], freq="28D")
    frame = build_frame(builder, cfg["name"], dates, spec["eval_label_end"])
    frame = frame.sort_values(["cutoff", "invoice_id"]).drop_duplicates("invoice_id").reset_index(drop=True)
    frame = attach(cfg["name"], frame, out)
    save_frame(path, frame)
    json_once(out / f"fresh_generation_receipt_{args.world_index}.json", {
        "world": cfg["name"], "seed": cfg["seed"], "selection_lock_sha256": digest(lock),
        "protocol_sha256": digest(out / "protocol.lock.json"), "frame_sha256": digest(path),
        "n_anchors": len(frame), "generator_config": cfg,
    })
    print(f"Fresh preparation complete: {cfg['name']}, {len(frame)} anchors", flush=True)


if __name__ == "__main__":
    main()
