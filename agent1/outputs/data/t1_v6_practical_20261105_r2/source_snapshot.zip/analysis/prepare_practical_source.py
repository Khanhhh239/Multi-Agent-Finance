"""Prepare one independent source World with the locked experiment functions.

Do not target a World another process is currently preparing. The primary runner
reuses a World only after both cached frames and their hashes are complete.
"""
import argparse
from pathlib import Path

import pandas as pd

from experiments.t1_v6_practical.run import ORIGINAL, ROOT, prepare, digest, load_world, build_frame, attach, save_frame


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world-index", type=int, required=True, choices=range(4))
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/data/t1_v6_practical_20261105_r2")
    args = parser.parse_args()
    out = args.output.resolve()
    if not out.is_relative_to((ROOT / "outputs/data").resolve()):
        raise ValueError("Use a separate experiment directory")
    spec, meta = prepare(out)
    detail = meta["world_audit"][args.world_index]
    world = detail["world"]
    cache = ORIGINAL / "cache" / f"train_{world}.parquet"
    if digest(cache) != detail["cache_sha256"]:
        raise ValueError("Original source cache changed")
    cached = pd.read_parquet(cache)
    fit = cached[cached.partition.eq("fit")].reset_index(drop=True)
    builder, _ = load_world(world)
    reserved = detail["firms"]["calibration_fit"] + detail["firms"]["calibration_select"]
    builder.inv = builder.inv[builder.inv.firm_id.isin(reserved)].copy()
    dates = pd.date_range(spec["eval_first_cutoff"], spec["eval_last_cutoff"], freq="28D")
    val = build_frame(builder, world, dates, spec["eval_label_end"])
    val = val.sort_values(["cutoff", "invoice_id"]).drop_duplicates("invoice_id").reset_index(drop=True)
    if set(val.firm_id) & set(fit.firm_id):
        raise ValueError("Reserved source companies overlap fit")
    print(f"Independent preparation: {world}", flush=True)
    enriched = attach(world, pd.concat([fit, val], ignore_index=True), out)
    save_frame(out / "prepared" / f"{world}_fit.parquet", enriched.iloc[:len(fit)].copy())
    save_frame(out / "prepared" / f"{world}_validation.parquet", enriched.iloc[len(fit):].copy())
    print(f"Independent preparation complete: {world}", flush=True)


if __name__ == "__main__":
    main()
