"""Prepare one disjoint augmentation World after the source support trigger.

Run indices 0 and 1 independently, then --collect after both finish. This uses
the same locked functions, seeds and sampling as the sequential runner. Do not
run its augmentation stage concurrently with these preparation workers.
"""
import argparse
from pathlib import Path

import pandas as pd

from experiments.t1_v6_practical.run import ROOT, ORIGINAL, prepare, make_world, load_world, build_frame, balanced_sample, attach, save_frame, read_frame


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world-index", type=int, choices=[0, 1])
    parser.add_argument("--collect", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT / "outputs/data/t1_v6_practical_20261105_r2")
    args = parser.parse_args()
    out = args.output.resolve()
    if not out.is_relative_to((ROOT / "outputs/data").resolve()):
        raise ValueError("Use an isolated experiment directory")
    spec, _ = prepare(out)
    if not (out / "primary_selection.json").exists():
        raise ValueError("Primary source selection must finish first")
    support = pd.read_csv(out / "primary_source_support.csv")
    rule = spec["support_trigger"]
    if not (support.feature.isin(rule["features"]) & support.outside_train_range_fraction.gt(rule["max_outside_train_range_fraction"])).any():
        raise ValueError("Source support did not trigger augmentation")
    paths = [out / "augmentation_parts" / f"{i}.parquet" for i in range(2)]
    if args.collect:
        save_frame(out / "augmented_fit.parquet", pd.concat([read_frame(p) for p in paths], ignore_index=True))
        print("Collected both augmentation Worlds", flush=True)
        return
    if args.world_index is None:
        raise ValueError("Specify --world-index or --collect")
    i = args.world_index
    cfg = spec["augment_worlds"][i]
    make_world(out, cfg)
    builder, _ = load_world(cfg["name"])
    import json
    old = json.loads((ORIGINAL / "protocol.lock.json").read_text(encoding="utf-8"))
    dates = pd.date_range(old["train_first_cutoff"], old["train_last_cutoff"], freq="28D")
    frame = build_frame(builder, cfg["name"], dates, old["train_label_end"])
    frame = balanced_sample(frame, 50000, 202611051 + i).reset_index(drop=True)
    print(f"Augmentation observed features: {cfg['name']}, {len(frame)} snapshots", flush=True)
    frame = attach(cfg["name"], frame, out)
    save_frame(paths[i], frame)
    print(f"Augmentation preparation complete: {cfg['name']}", flush=True)


if __name__ == "__main__":
    main()
